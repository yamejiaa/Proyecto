<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar Contraseña</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="min-h-screen flex items-center justify-center p-4">
    <div class="bg-white rounded-lg shadow-2xl overflow-hidden w-full max-w-md transform transition-all duration-500">
        <div class="bg-gradient-to-r from-blue-600 to-purple-500 p-6 text-white">
            <h1 class="text-2xl font-bold flex items-center gap-2 flex items-center justify-center">
                <i class="fas fa-key"></i> Recuperar Contraseña
            </h1>
            <p class="text-blue-100 text-center">Ingresa tu correo para recibir un código de verificación</p>
        </div>
        
        <form class="p-6 space-y-6" id="emailForm" action="../includes/reset.php" method="POST">
            <div class="space-y-4">
                <div>
                    <label for="email" class="block text-sm font-medium text-gray-700 mb-1">Correo Electrónico</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-envelope text-gray-400"></i>
                        </div>
                        <input type="email" id="email" name="email" required
                            class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-300"
                            placeholder="tu@email.com">
                    </div>
                </div>
            </div>
            
            <div>
                <button type="submit"
                    class="w-full flex justify-center flex items-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-300">
                    <i class="fas fa-paper-plane mr-2"></i> Enviar Código
                </button>
            </div>
        </form>
        
        <div class="px-6 py-4 bg-gray-50 text-center">
            <p class="text-sm text-gray-600">
                ¿Recuerdas tu contraseña? 
                <a href="login.php" class="font-medium text-blue-600 hover:text-blue-500 transition duration-300">Inicia Sesión</a>
            </p>
        </div>
    </div>

    <script src="../assets/js/auth.js"></script>
</body>
</html>