<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificación de Código</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/auth.css">
</head>
<body class="min-h-screen flex items-center justify-center p-4">
    <div class="bg-white rounded-lg shadow-2xl overflow-hidden w-full max-w-md transform transition-all duration-500 hover:scale-[1.02]">
        <div class="bg-gradient-to-r from-blue-600 to-purple-500 p-6 text-white">
            <h1 class="text-2xl font-bold flex items-center gap-2 flex items-center justify-center">
                <i class="fas fa-shield-alt"></i> Verificación
            </h1>
            <p class="text-blue-100 text-center">Ingresa el código de 6 dígitos enviado a tu correo</p>
        </div>
        
        <form class="p-6 space-y-6" id="codeForm">
            <div class="space-y-4">
                <div class="text-center">
                    <p class="text-sm text-gray-600 mb-4">Hemos enviado un código a <span class="font-medium">usuario@ejemplo.com</span></p>
                    
                    <div class="flex justify-center space-x-3 mb-6" id="codeContainer">
                        <input type="text" maxlength="1" class="code-input" pattern="[0-9]" required data-index="0">
                        <input type="text" maxlength="1" class="code-input" pattern="[0-9]" required data-index="1">
                        <input type="text" maxlength="1" class="code-input" pattern="[0-9]" required data-index="2">
                        <input type="text" maxlength="1" class="code-input" pattern="[0-9]" required data-index="3">
                        <input type="text" maxlength="1" class="code-input" pattern="[0-9]" required data-index="4">
                        <input type="text" maxlength="1" class="code-input" pattern="[0-9]" required data-index="5">
                    </div>
                    
                    <div class="mb-4">
                        <p class="text-sm font-medium text-gray-700">Tiempo restante: <span id="countdown" class="text-red-500">05:00</span></p>
                    </div>
                    
                    <div id="resendCode" class="hidden">
                        <button type="button" class="text-blue-600 hover:text-blue-500 font-medium transition duration-300">
                            <i class="fas fa-sync-alt mr-1"></i> Reenviar código
                        </button>
                    </div>
                </div>
            </div>
            
            <div>
                <button type="submit"
                    class="w-full flex justify-center flex items-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-300">
                    <i class="fas fa-check-circle mr-2"></i> Verificar Código
                </button>
            </div>
        </form>
        
        <div class="px-6 py-4 bg-gray-50 text-center">
            <p class="text-sm text-gray-600">
                ¿No recibiste el código? 
                <button id="showResend" class="font-medium text-blue-600 hover:text-blue-500 transition duration-300">Reenviar</button>
            </p>
        </div>
    </div>

    <script>// Manejo de los inputs del código
        const codeInputs = document.querySelectorAll('.code-input');
        
        codeInputs.forEach((input, index) => {
            // Auto-enfocar el primer input al cargar
            if (index === 0) {
                input.focus();
            }
            
            // Manejar entrada de datos
            input.addEventListener('input', (e) => {
                if (e.target.value.length === 1) {
                    e.target.classList.add('filled');
                    
                    // Mover al siguiente input si existe
                    if (index < codeInputs.length - 1) {
                        codeInputs[index + 1].focus();
                    } else {
                        // Si es el último input, enviar el formulario
                        document.getElementById('codeForm').dispatchEvent(new Event('submit'));
                    }
                }
            });
            
            // Manejar tecla Backspace
            input.addEventListener('keydown', (e) => {
                if (e.key === 'Backspace' && e.target.value.length === 0 && index > 0) {
                    e.preventDefault();
                    codeInputs[index - 1].focus();
                    codeInputs[index - 1].value = '';
                    codeInputs[index - 1].classList.remove('filled');
                }
            });
            
            // Manejar pegado de código completo
            input.addEventListener('paste', (e) => {
                e.preventDefault();
                const pasteData = e.clipboardData.getData('text');
                if (/^\d{6}$/.test(pasteData)) {
                    for (let i = 0; i < pasteData.length && i < codeInputs.length; i++) {
                        codeInputs[i].value = pasteData[i];
                        codeInputs[i].classList.add('filled');
                    }
                    // Enfocar el último input
                    codeInputs[Math.min(pasteData.length - 1, codeInputs.length - 1)].focus();
                }
            });
        });
        
        // Simular cuenta regresiva
        let timeLeft = 300; // 5 minutos en segundos
        const countdownElement = document.getElementById('countdown');
        const resendCodeElement = document.getElementById('resendCode');
        
        const countdown = setInterval(() => {
            const minutes = Math.floor(timeLeft / 60);
            const seconds = timeLeft % 60;
            
            countdownElement.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            
            if (timeLeft <= 0) {
                clearInterval(countdown);
                countdownElement.textContent = "00:00";
                resendCodeElement.classList.remove('hidden');
            }
            
            timeLeft--;
        }, 1000);
        
        // Mostrar opción de reenvío
        document.getElementById('showResend').addEventListener('click', function() {
            resendCodeElement.classList.remove('hidden');
        });
        
        // Simular verificación exitosa
        document.getElementById('codeForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Obtener el código completo
            let fullCode = '';
            codeInputs.forEach(input => {
                fullCode += input.value;
            });
            
            // Validar que todos los dígitos estén completos
            if (fullCode.length === 6) {
                // Redirigir al formulario de nueva contraseña
                window.location.href = 'nueva-contrasena.html';
            } else {
                alert('Por favor ingresa el código completo de 6 dígitos');
                // Enfocar el primer campo vacío
                for (let i = 0; i < codeInputs.length; i++) {
                    if (!codeInputs[i].value) {
                        codeInputs[i].focus();
                        break;
                    }
                }
            }
        });
        </script>
</body>
</html>