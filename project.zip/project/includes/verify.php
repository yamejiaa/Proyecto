<?php
session_start();

if (!isset($_SESSION['reset_email'])) {
    header("Location: reset.php");
    exit();
}

require_once 'conexion.php';
require_once '../vendor/autoload.php'; // Asegúrate de que esta ruta es correcta

$error_message = "";
$email = $_SESSION['reset_email'];

// Función idéntica a la de reset.php
function sendVerificationEmail($email, $verification_code) {
    $mail = new PHPMailer\PHPMailer\PHPMailer(true);
    
    try {
        // Configuración del servidor SMTP (debe coincidir con reset.php)
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'ymejia0223@gmail.com';
        $mail->Password = 'ebcjrrfjbtmzpdja';
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port = 465;
        
        // Configuración del correo (usa tu email real como remitente)
        $mail->setFrom('ymejia0223@gmail.com', 'Sistema de Recuperacion'); // Cambiado a tu email real
        $mail->addAddress($email);
        $mail->Subject = 'Codigo de verificacion para recuperacion de contrasena';
        $mail->Body = "Tu nuevo codigo de verificacion es: $verification_code\n\nEste codigo expirara en 1 minuto.";
        
        return $mail->send();
    } catch (Exception $e) {
        error_log("Error al enviar correo: " . $mail->ErrorInfo);
        return false;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $entered_code = "";
    for ($i = 0; $i < 6; $i++) {
        $entered_code .= $_POST['code_' . $i] ?? '';
    }
    
    if ($entered_code == $_SESSION['verification_code']) {
        if (time() > $_SESSION['code_expiration']) {
            $error_message = "El código ha expirado. Por favor solicite uno nuevo.";
        } else {
            header("Location: password.php");
            exit();
        }
    } else {
        $error_message = "Código de verificación incorrecto";
    }
}

if (isset($_GET['resend'])) {
    $verification_code = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
    $expiration = time() + 60;
    
    $_SESSION['verification_code'] = $verification_code;
    $_SESSION['code_expiration'] = $expiration;
    
    // Usamos la misma función de envío
    if (sendVerificationEmail($email, $verification_code)) {
        header("Location: verify.php?email=" . urlencode($email));
        exit();
    } else {
        $error_message = "Error al reenviar el código. Por favor intente nuevamente.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificación de Código</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .code-input {
            width: 40px;
            height: 50px;
            text-align: center;
            font-size: 1.2rem;
            border: 1px solid #d1d5db;
            border-radius: 0.375rem;
        }
        .code-input.error {
            border-color: #ef4444;
            box-shadow: 0 0 0 2px rgba(239, 68, 68, 0.2);
        }
    </style>
</head>
<body class="min-h-screen flex items-center justify-center p-4">
    <div class="bg-white rounded-lg shadow-2xl overflow-hidden w-full max-w-md transform transition-all duration-500">
        <div class="bg-gradient-to-r from-blue-600 to-purple-500 p-6 text-white">
            <h1 class="text-2xl font-bold flex items-center gap-2 flex items-center justify-center">
                <i class="fas fa-shield-alt"></i> Verificación
            </h1>
            <p class="text-blue-100 text-center">Ingresa el código de 6 dígitos enviado a tu correo</p>
        </div>
        
        <form class="p-6 space-y-6" id="codeForm" method="POST" action="verify.php">
            <?php if (!empty($error_message)): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                    <span class="block sm:inline"><?php echo $error_message; ?></span>
                    <?php if ($error_message == "Código de verificación incorrecto"): ?>
                        <a href="verify.php?resend=1" class="text-blue-600 hover:text-blue-500 font-medium block mt-1">
                            <i class="fas fa-sync-alt mr-1"></i> Reenviar código
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
            <div class="space-y-4">
                <div class="text-center">
                    <p class="text-sm text-gray-600 mb-4">Hemos enviado un código a <span class="font-medium"><?php echo htmlspecialchars($email); ?></span></p>
                    
                    <div class="flex justify-center space-x-3 mb-6" id="codeContainer">
                        <?php for ($i = 0; $i < 6; $i++): ?>
                            <input type="text" maxlength="1" name="code_<?php echo $i; ?>" class="code-input <?php echo !empty($error_message) ? 'error' : ''; ?>" pattern="[0-9]" required data-index="<?php echo $i; ?>">
                        <?php endfor; ?>
                    </div>
                    
                    <?php if (isset($_SESSION['code_expiration']) && time() < $_SESSION['code_expiration']): ?>
                        <div class="mb-4">
                            <p class="text-sm font-medium text-gray-700">Tiempo restante: <span id="countdown" class="text-red-500">00:30</span></p>
                        </div>
                    <?php endif; ?>
                    
                    <div id="resendCode" class="<?php echo (time() > $_SESSION['code_expiration']) ? '' : 'hidden'; ?>">
                        <a href="verify.php?resend=1" class="text-blue-600 hover:text-blue-500 font-medium transition duration-300">
                            <i class="fas fa-sync-alt mr-1"></i> Reenviar código
                        </a>
                    </div>
                </div>
            </div>
            
            <div>
                <button type="submit"
                    class="w-full flex justify-center flex items-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-300">
                    <i class="fas fa-check-circle mr-2"></i> Verificar Código
                </button>
            </div>
        </form>
    </div>

    <script>
        const codeInputs = document.querySelectorAll('.code-input');
        
        codeInputs.forEach((input, index) => {
            if (index === 0) {
                input.focus();
            }
            
            input.addEventListener('input', (e) => {
                if (e.target.value.length === 1) {
                    e.target.classList.add('filled');
                    
                    if (index < codeInputs.length - 1) {
                        codeInputs[index + 1].focus();
                    }
                }
            });
            
            input.addEventListener('keydown', (e) => {
                if (e.key === 'Backspace' && e.target.value.length === 0 && index > 0) {
                    e.preventDefault();
                    codeInputs[index - 1].focus();
                    codeInputs[index - 1].value = '';
                    codeInputs[index - 1].classList.remove('filled');
                }
            });
            
            input.addEventListener('paste', (e) => {
                e.preventDefault();
                const pasteData = e.clipboardData.getData('text');
                if (/^\d{6}$/.test(pasteData)) {
                    for (let i = 0; i < pasteData.length && i < codeInputs.length; i++) {
                        codeInputs[i].value = pasteData[i];
                        codeInputs[i].classList.add('filled');
                    }
                    codeInputs[Math.min(pasteData.length - 1, codeInputs.length - 1)].focus();
                }
            });
        });
        
        let timeLeft = <?php echo ($_SESSION['code_expiration'] - time()) > 0 ? ($_SESSION['code_expiration'] - time()) : 0; ?>;
        const countdownElement = document.getElementById('countdown');
        const resendCodeElement = document.getElementById('resendCode');
        
        if (countdownElement) {
            const countdown = setInterval(() => {
                const minutes = Math.floor(timeLeft / 60);
                const seconds = timeLeft % 60;
                
                countdownElement.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
                
                if (timeLeft <= 0) {
                    clearInterval(countdown);
                    countdownElement.textContent = "00:00";
                    if (resendCodeElement) {
                        resendCodeElement.classList.remove('hidden');
                    }
                }
                
                timeLeft--;
            }, 1000);
        }
    </script>
</body>
</html>