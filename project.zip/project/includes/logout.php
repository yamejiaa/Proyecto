<?php
session_start();

// Verificar si hay una sesión activa para registrar el log
if (isset($_SESSION['user_id'])) {
    require_once 'conexion.php'; // Asegúrate de incluir tu conexión a la base de datos

    try {
        // Registrar el log de cierre de sesión
        $pdo->prepare("CALL sp_registrar_log_autenticacion(?, 'logout', ?, ?, ?)")
            ->execute([
                $_SESSION['user_id'],
                $_SERVER['REMOTE_ADDR'],
                $_SERVER['HTTP_USER_AGENT'],
                'Cierre de sesión exitoso'
            ]);
    } catch (PDOException $e) {
        // Puedes registrar este error en un archivo de log si lo deseas
        error_log("Error al registrar log de cierre de sesión: " . $e->getMessage());
    }
}

// Destruir todas las variables de sesión
$_SESSION = array();

// Si se desea destruir la sesión completamente, borrar también la cookie de sesión
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Destruir la sesión
session_destroy();

// Redirigir al login con mensaje de éxito
header("Location: ../auth/login.php?success=Has cerrado sesión correctamente");
exit();
?>