<?php
session_start();

if (!isset($_SESSION['reset_email'])) {
    header("Location: reset.php");
    exit();
}

require_once 'conexion.php';

$success_message = "";
$error_message = "";
$tipoMensaje = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_password = $_POST['new-password'] ?? '';
    $confirm_password = $_POST['confirm-password'] ?? '';
    
    if ($new_password !== $confirm_password) {
        $error_message = "Las contraseñas no coinciden";
        $tipoMensaje = "error";
    } elseif (strlen($new_password) < 8 || !preg_match('/[A-Za-z]/', $new_password) || !preg_match('/[0-9]/', $new_password)) {
        $error_message = "La contraseña debe tener al menos 8 caracteres, incluyendo letras y números";
        $tipoMensaje = "error";
    } else {
        $hashed_password = password_hash($new_password, PASSWORD_BCRYPT);
        $email = $_SESSION['reset_email'];
        
        try {
            $sql = "UPDATE usuarios SET contrasena = ?, intentos_fallidos = 0 WHERE email = ?";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$hashed_password, $email]);
            
            // Registrar el evento en logs
            $sql_log = "INSERT INTO logs_autenticacion (cedula_usuario, tipo_evento, direccion_ip, user_agent, detalles) 
                         SELECT cedula, 'recuperacion', ?, ?, 'Contraseña actualizada exitosamente' 
                         FROM usuarios WHERE email = ?";
            $stmt_log = $pdo->prepare($sql_log);
            $ip = $_SERVER['REMOTE_ADDR'];
            $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
            $stmt_log->execute([$ip, $user_agent, $email]);
            
            $success_message = "Contraseña actualizada correctamente";
            $tipoMensaje = "exito";
            
            // Limpiar la sesión
            unset($_SESSION['reset_email']);
            unset($_SESSION['verification_code']);
            unset($_SESSION['code_expiration']);
            
        } catch (PDOException $e) {
            $error_message = "Error al actualizar la contraseña. Por favor intente nuevamente.";
            $tipoMensaje = "error";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nueva Contraseña</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="min-h-screen flex items-center justify-center p-4">
    <div class="bg-white rounded-lg shadow-2xl overflow-hidden w-full max-w-md transform transition-all duration-500">
        <div class="bg-gradient-to-r from-blue-600 to-purple-500 p-6 text-white">
            <h1 class="text-2xl font-bold flex items-center gap-2 flex items-center justify-center">
                <i class="fas fa-key"></i> Nueva Contraseña
            </h1>
            <p class="text-blue-100 text-center">Crea una nueva contraseña segura</p>
        </div>
        
        <form class="p-6 space-y-6" id="newPasswordForm" method="POST" action="password.php">
            <div class="space-y-4">
                <div>
                    <label for="new-password" class="block text-sm font-medium text-gray-700 mb-1">Nueva Contraseña</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-lock text-gray-400"></i>
                        </div>
                        <input type="password" id="new-password" name="new-password" required
                            class="block w-full pl-10 pr-10 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-300"
                            placeholder="••••••••">
                        <button type="button" id="toggleNewPassword" class="absolute inset-y-0 right-0 pr-3 flex items-center">
                            <i class="fas fa-eye text-gray-400 hover:text-gray-600 cursor-pointer"></i>
                        </button>
                    </div>
                    <p class="mt-1 text-xs text-gray-500">Mínimo 8 caracteres con números y letras</p>
                </div>
                
                <div>
                    <label for="confirm-password" class="block text-sm font-medium text-gray-700 mb-1">Confirmar Nueva Contraseña</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-lock text-gray-400"></i>
                        </div>
                        <input type="password" id="confirm-password" name="confirm-password" required
                            class="block w-full pl-10 pr-10 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-300"
                            placeholder="••••••••">
                        <button type="button" id="toggleConfirmPassword" class="absolute inset-y-0 right-0 pr-3 flex items-center">
                            <i class="fas fa-eye text-gray-400 hover:text-gray-600 cursor-pointer"></i>
                        </button>
                    </div>
                </div>
            </div>
            
            <div>
                <button type="submit"
                    class="w-full flex justify-center flex items-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-300">
                    <i class="fas fa-save mr-2"></i> Actualizar Contraseña
                </button>
            </div>
        </form>
    </div>

    <!-- Modal de Éxito -->
    <?php if ($tipoMensaje == "exito"): ?>
    <div id="modalExito" class="fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50">
        <div class="bg-white rounded-lg p-6 max-w-sm w-full mx-4 text-center">
            <div class="text-green-500 mb-4">
                <i class="fas fa-check-circle text-6xl animate-bounce"></i>
            </div>
            <h3 class="text-lg font-medium text-gray-900 mb-2">¡Contraseña actualizada!</h3>
            <p class="text-sm text-gray-500"><?php echo $success_message; ?></p>
            <p class="text-xs text-gray-400 mt-4">Redirigiendo al login...</p>
        </div>
    </div>
    <script>
        setTimeout(function() {
            window.location.href = '../auth/login.php';
        }, 3000);
    </script>
    <?php endif; ?>

    <!-- Modal de Error -->
    <?php if ($tipoMensaje == "error"): ?>
    <div id="modalError" class="fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50">
        <div class="bg-white rounded-lg p-6 max-w-sm w-full mx-4 text-center">
            <div class="text-red-500 mb-4">
                <i class="fas fa-exclamation-circle text-6xl animate-spin-slow"></i>
            </div>
            <h3 class="text-lg font-medium text-gray-900 mb-2">Error</h3>
            <p class="text-sm text-gray-500"><?php echo $error_message; ?></p>
            <p class="text-xs text-gray-400 mt-4">Esta ventana se cerrará automáticamente</p>
        </div>
    </div>
    <script>
        setTimeout(function() {
            document.getElementById('modalError').remove();
        }, 3000);
    </script>
    <?php endif; ?>

    <script>
        document.getElementById('toggleNewPassword').addEventListener('click', function() {
            const passwordInput = document.getElementById('new-password');
            const icon = this.querySelector('i');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.classList.replace('fa-eye', 'fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                icon.classList.replace('fa-eye-slash', 'fa-eye');
            }
        });
        
        document.getElementById('toggleConfirmPassword').addEventListener('click', function() {
            const confirmPasswordInput = document.getElementById('confirm-password');
            const icon = this.querySelector('i');
            
            if (confirmPasswordInput.type === 'password') {
                confirmPasswordInput.type = 'text';
                icon.classList.replace('fa-eye', 'fa-eye-slash');
            } else {
                confirmPasswordInput.type = 'password';
                icon.classList.replace('fa-eye-slash', 'fa-eye');
            }
        });
        
        document.getElementById('new-password').addEventListener('input', function() {
            const password = this.value;
            const hasLength = password.length >= 8;
            const hasLetter = /[A-Za-z]/.test(password);
            const hasNumber = /[0-9]/.test(password);
            
            if (!hasLength || !hasLetter || !hasNumber) {
                this.classList.add('border-red-500');
            } else {
                this.classList.remove('border-red-500');
            }
        });
    </script>
</body>
</html>