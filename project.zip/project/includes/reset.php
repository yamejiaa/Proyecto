<?php
session_start();
require_once 'conexion.php';
require_once '../vendor/autoload.php';

$error_message = "";
$email_value = "";

function sendVerificationEmail($email, $verification_code) {
    $mail = new PHPMailer\PHPMailer\PHPMailer(true);
    
    try {
        // Configuración del servidor SMTP (ajusta estos valores)
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com'; // Cambia por tu servidor SMTP
        $mail->SMTPAuth = true;
        $mail->Username = 'ymejia0223@gmail.com'; // Tu correo SMTP
        $mail->Password = 'ebcjrrfjbtmzpdja'; // Tu contraseña SMTP
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port = 465;
        
        // Configuración del correo
        $mail->setFrom('no-reply@tudominio.com', 'Sistema de Recuperacion');
        $mail->addAddress($email);
        $mail->Subject = 'Codigo de verificacion para recuperacion de contrasena';
        $mail->Body = "Tu codigo de verificacion es: $verification_code\n\nEste codigo expirara en 1 minuto.";
        
        return $mail->send();
    } catch (Exception $e) {
        error_log("Error al enviar correo: " . $mail->ErrorInfo);
        return false;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'] ?? '';
    $email_value = htmlspecialchars($email);
    
    // Verificar si el correo existe en la base de datos
    $sql = "SELECT cedula, estado FROM usuarios WHERE email = ?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user) {
        // Verificar estado de la cuenta
        if ($user['estado'] == 'bloqueado') {
            $error_message = "Cuenta bloqueada, contacte al administrador";
        } else {
            // Generar código de verificación de 6 dígitos
            $verification_code = str_pad(rand(0, 999999), 6, '0', STR_PAD_LEFT);
            $expiration = time() + 60; // 30 segundos para expirar
            
            // Enviar correo con el código
            if (sendVerificationEmail($email, $verification_code)) {
                // Guardar en sesión y redirigir
                $_SESSION['reset_email'] = $email;
                $_SESSION['verification_code'] = $verification_code;
                $_SESSION['code_expiration'] = $expiration;
                
                header("Location: verify.php?email=" . urlencode($email));
                exit();
            } else {
                $error_message = "Error al enviar el código. Por favor intente nuevamente.";
            }
        }
    } else {
        $error_message = "El correo electrónico ingresado no existe";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar Contraseña</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="min-h-screen flex items-center justify-center p-4">
    <div class="bg-white rounded-lg shadow-2xl overflow-hidden w-full max-w-md transform transition-all duration-500">
        <div class="bg-gradient-to-r from-blue-600 to-purple-500 p-6 text-white">
            <h1 class="text-2xl font-bold flex items-center gap-2 flex items-center justify-center">
                <i class="fas fa-key"></i> Recuperar Contraseña
            </h1>
            <p class="text-blue-100 text-center">Ingresa tu correo para recibir un código de verificación</p>
        </div>
        
        <form class="p-6 space-y-6" id="emailForm" method="POST" action="reset.php">
            <?php if (!empty($error_message)): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                    <span class="block sm:inline"><?php echo $error_message; ?></span>
                </div>
            <?php endif; ?>
            
            <div class="space-y-4">
                <div>
                    <label for="email" class="block text-sm font-medium text-gray-700 mb-1">Correo Electrónico</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-envelope text-gray-400"></i>
                        </div>
                        <input type="email" id="email" name="email" required value="<?php echo $email_value; ?>"
                            class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-300"
                            placeholder="tu@email.com">
                    </div>
                </div>
            </div>
            
            <div>
                <button type="submit"
                    class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-300">
                    <i class="fas fa-paper-plane mr-2"></i> Enviar Código
                </button>
            </div>
        </form>
        
        <div class="px-6 py-4 bg-gray-50 text-center">
            <p class="text-sm text-gray-600">
                ¿Recuerdas tu contraseña? 
                <a href="../auth/login.php" class="font-medium text-blue-600 hover:text-blue-500 transition duration-300">Inicia Sesión</a>
            </p>
        </div>
    </div>
</body>
</html>