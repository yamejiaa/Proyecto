<?php
session_start();
require_once 'conexion.php';

$error_message = "";
$mensaje = "";
$tipoMensaje = "";
$redirect_url = ""; // Nueva variable para almacenar la URL de redirección

// Procesar el formulario de login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $remember = isset($_POST['remember-me']) ? true : false;

    try {
        // Verificar si el correo existe
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {
            $error_message = "El correo electrónico ingresado no existe";
            $tipoMensaje = "error";
        } else {
            // Verificar estado de la cuenta
            if ($user['estado'] === 'bloqueado') {
                $error_message = "Cuenta bloqueada. Contacte al administrador";
                $tipoMensaje = "error";
            } else {
                // Verificar contraseña
                if (password_verify($password, $user['contrasena'])) {
                    // Contraseña correcta - reiniciar intentos fallidos
                    $pdo->prepare("CALL sp_actualizar_intentos_fallidos(?, false, @estado)")->execute([$user['cedula']]);
                    
                    // Registrar log de autenticación
                    $ip = $_SERVER['REMOTE_ADDR'];
                    $user_agent = $_SERVER['HTTP_USER_AGENT'];
                    $pdo->prepare("CALL sp_registrar_log_autenticacion(?, 'login', ?, ?, ?)")
                        ->execute([$user['cedula'], $ip, $user_agent, 'Inicio de sesión exitoso']);
                    
                    // Actualizar último login
                    $pdo->prepare("UPDATE usuarios SET ultimo_login = NOW() WHERE cedula = ?")
                        ->execute([$user['cedula']]);
                    
                    // Establecer sesión
                    $_SESSION['user_id'] = $user['cedula'];
                    $_SESSION['user_email'] = $user['email'];
                    $_SESSION['user_role'] = $user['id_rol'];
                    $_SESSION['loggedin'] = true;
                    
                    // Recordar usuario si está marcado
                    if ($remember) {
                        $cookie_value = base64_encode($user['email'] . ':' . password_hash($user['contrasena'], PASSWORD_DEFAULT));
                        setcookie('remember_user', $cookie_value, time() + (86400 * 30), "/"); // 30 días
                    }
                    
                    $mensaje = "Inicio de sesión exitoso. Bienvenido!";
                    $tipoMensaje = "exito";
                    
                    // Determinar la URL de redirección basada en el rol
                    $redirect_url = ($user['id_rol'] == 1) ? '../admin/index.php' : '../principal.php';
                } else {
                    // Contraseña incorrecta - incrementar intentos fallidos
                    $pdo->prepare("CALL sp_actualizar_intentos_fallidos(?, true, @estado)")->execute([$user['cedula']]);
                    
                    // Obtener el estado actual después de actualizar los intentos
                    $stmt = $pdo->query("SELECT @estado AS estado");
                    $result = $stmt->fetch(PDO::FETCH_ASSOC);
                    $estado = $result['estado'];
                    
                    // Obtener intentos restantes
                    $stmt = $pdo->prepare("SELECT intentos_fallidos FROM usuarios WHERE cedula = ?");
                    $stmt->execute([$user['cedula']]);
                    $intentos = $stmt->fetchColumn();
                    $intentos_restantes = 5 - $intentos;
                    
                    if ($estado === 'bloqueado') {
                        $error_message = "Cuenta bloqueada. Contacte al administrador";
                        $tipoMensaje = "error";
                        
                        // Registrar log de bloqueo
                        $ip = $_SERVER['REMOTE_ADDR'];
                        $user_agent = $_SERVER['HTTP_USER_AGENT'];
                        $pdo->prepare("CALL sp_registrar_log_autenticacion(?, 'bloqueo', ?, ?, ?)")
                            ->execute([$user['cedula'], $ip, $user_agent, 'Cuenta bloqueada por múltiples intentos fallidos']);
                    } else {
                        $error_message = "Contraseña incorrecta. Te quedan {$intentos_restantes} intentos";
                        $tipoMensaje = "error";
                    }
                }
            }
        }
    } catch (PDOException $e) {
        $error_message = "Error en el sistema. Por favor, intente más tarde.";
        $tipoMensaje = "error";
        error_log("Error en login: " . $e->getMessage());
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio de Sesión</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body class="min-h-screen flex items-center justify-center p-4">
    <!-- Modal para mensajes -->
    <div id="messageModal" class="fixed top-4 right-4 z-50 hidden">
        <div class="<?php echo $tipoMensaje === 'success' ? 'bg-green-500' : 'bg-red-500'; ?> text-white px-6 py-4 rounded-lg shadow-lg flex items-center">
            <i class="fas <?php echo $tipoMensaje === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?> mr-2"></i>
            <span><?php echo !empty($success_message) ? $success_message : $error_message; ?></span>
            <button onclick="document.getElementById('messageModal').classList.add('hidden')" class="ml-4">
                <i class="fas fa-times"></i>
            </button>
        </div>
    </div>

    <div class="bg-white rounded-lg shadow-2xl overflow-hidden w-full max-w-md transform transition-all duration-500">
        <div class="bg-gradient-to-r from-blue-600 to-purple-500 p-6 text-white">
            <h1 class="text-2xl font-bold flex items-center gap-2 justify-center">
                <i class="fas fa-sign-in-alt"></i> Iniciar Sesión
            </h1>
            <p class="text-blue-100 text-center">Ingresa tus credenciales para acceder</p>
        </div>
        
        <form method="POST" class="p-6 space-y-6">
            <div class="space-y-4">
                <?php if ($tipoMensaje === 'error' && strpos($error_message, 'correo electrónico') !== false): ?>
                    <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-3 mb-4">
                        <p><?php echo $error_message; ?></p>
                    </div>
                <?php endif; ?>
                
                <div>

                <?php if ($tipoMensaje === 'error' && (strpos($error_message, 'Contraseña incorrecta') !== false || strpos($error_message, 'Cuenta bloqueada') !== false)): ?>
                    <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-3 mb-4">
                        <p><?php echo $error_message; ?></p>
                    </div>
                <?php endif; ?>

                    <label for="email" class="block text-sm font-medium text-gray-700 mb-1">Correo Electrónico</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-envelope text-gray-400"></i>
                        </div>
                        <input type="email" id="email" name="email" required
                            class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-300"
                            placeholder="tu@email.com" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                    </div>
                </div>
                
                <div>
                    <label for="password" class="block text-sm font-medium text-gray-700 mb-1">Contraseña</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-lock text-gray-400"></i>
                        </div>
                        <input type="password" id="password" name="password" required
                            class="block w-full pl-10 pr-10 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-300"
                            placeholder="••••••••">
                        <button type="button" id="togglePassword" class="absolute inset-y-0 right-0 pr-3 flex items-center">
                            <i class="fas fa-eye text-gray-400 hover:text-gray-600 cursor-pointer"></i>
                        </button>
                    </div>
                </div>
                
                <div class="flex items-center justify-between">
                    <div class="flex items-center">
                        <input id="remember-me" name="remember-me" type="checkbox" class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded">
                        <label for="remember-me" class="ml-2 block text-sm text-gray-700">Recordarme</label>
                    </div>
                    
                    <div class="text-sm">
                        <a href="reset.php" class="font-medium text-blue-600 hover:text-blue-500 transition duration-300">¿Olvidaste tu contraseña?</a>
                    </div>
                </div>
            </div>
            
            <div>
                <button type="submit"
                    class="w-full flex justify-center py-2 px-4 flex items-center border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-300">
                    <i class="fas fa-sign-in-alt mr-2"></i> Iniciar Sesión
                </button>
            </div>
        </form>
        
        <div class="px-6 py-4 bg-gray-50 text-center">
            <p class="text-sm text-gray-600">
                ¿No tienes una cuenta? 
                <a href="register.php" class="font-medium text-blue-600 hover:text-blue-500 transition duration-300">Regístrate</a>
            </p>
        </div>
    </div>

    <!-- Modal de Éxito -->
    <?php if ($tipoMensaje == "exito" && !empty($redirect_url)): ?>
    <div id="modalExito" class="fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50">
        <div class="bg-white rounded-lg p-6 max-w-sm w-full mx-4 text-center">
            <div class="text-green-500 mb-4">
                <i class="fas fa-check-circle text-6xl animate-bounce"></i>
            </div>
            <h3 class="text-lg font-medium text-gray-900 mb-2">¡Inicio de sesión exitoso!</h3>
            <p class="text-sm text-gray-500"><?php echo $mensaje; ?></p>
            <p class="text-xs text-gray-400 mt-4">Redirigiendo...</p>
        </div>
    </div>
    <script>
        setTimeout(function() {
            window.location.href = "<?php echo $redirect_url; ?>";
        }, 3000);
    </script>
    <?php endif; ?>

    <script>
        // Toggle para mostrar/ocultar contraseña
        document.getElementById('togglePassword').addEventListener('click', function() {
            const passwordInput = document.getElementById('password');
            const icon = this.querySelector('i');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.classList.replace('fa-eye', 'fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                icon.classList.replace('fa-eye-slash', 'fa-eye');
            }
        });
    </script>
</body>
</html>