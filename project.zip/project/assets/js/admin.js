// Sidebar functionality
document.addEventListener('DOMContentLoaded', function() {
    const sidebar = document.getElementById('sidebar');
    const mobileMenuButton = document.getElementById('mobile-menu-button');
    const closeSidebarButton = document.getElementById('close-sidebar');
    const overlay = document.getElementById('overlay');
    const logoContainer = document.querySelector('#sidebar .flex.items-center.justify-between');
    
    // Elementos para los dropdowns
    const notificationBtn = document.getElementById('notification-btn');
    const notificationDropdown = document.getElementById('notification-dropdown');
    const profileDropdownBtn = document.getElementById('profile-dropdown-btn');
    const profileDropdown = document.getElementById('profile-dropdown');
    
    // Ajustar el ancho del sidebar cuando está colapsado
    if (window.innerWidth >= 1024) {
        sidebar.classList.add('lg:w-24'); // Aumentamos el ancho para que el avatar se vea mejor
    }
    
    // Centrar iconos cuando sidebar está colapsado
    function centerIconsWhenCollapsed() {
        if (window.innerWidth >= 1024) {
            const sidebarItems = document.querySelectorAll('#sidebar .sidebar-item');
            // Centrar logo y título cuando está expandido
            if (sidebar.classList.contains('lg:w-72')) {
                logoContainer.classList.add('flex-col', 'text-center', 'items-center');
                logoContainer.classList.remove('justify-between');
            } else {
                logoContainer.classList.remove('flex-col', 'text-center', 'items-center');
                logoContainer.classList.add('justify-between');
            }
            // Manejar específicamente el logo
        if (sidebar.classList.contains('lg:w-24') || sidebar.classList.contains('lg:w-20')) {
            logoContainer.classList.add('px-0');
            logoContainer.querySelector('div').classList.add('mx-auto');
        } else {
            logoContainer.classList.remove('px-0');
            logoContainer.querySelector('div').classList.remove('mx-auto');
        }
    }
    }
    // Toggle sidebar on mobile
    mobileMenuButton.addEventListener('click', function() {
        sidebar.classList.toggle('-translate-x-full');
        overlay.classList.toggle('hidden');
        closeAllDropdowns();
        centerIconsWhenCollapsed();
    });
    
    // Close sidebar on close button click
    closeSidebarButton.addEventListener('click', function() {
        sidebar.classList.add('-translate-x-full');
        overlay.classList.add('hidden');
        closeAllDropdowns();
        centerIconsWhenCollapsed();
    });
    
    // Close sidebar when clicking outside
    overlay.addEventListener('click', function() {
        sidebar.classList.add('-translate-x-full');
        overlay.classList.add('hidden');
        closeAllDropdowns();
        centerIconsWhenCollapsed();
    });
    
    // Función para cerrar todos los dropdowns
    function closeAllDropdowns() {
        closeNotificationDropdown();
        closeProfileDropdown();
    }
    
    function toggleNotificationDropdown() {
    // Si ya está abierto, cerrarlo
    if (!notificationDropdown.classList.contains('hidden')) {
        closeNotificationDropdown();
        return;
    }
    
    // Cerrar otros dropdowns primero
    closeProfileDropdown();
    
    // Posicionar siempre debajo del botón
    notificationDropdown.classList.remove('top-full', 'mt-2', 'bottom-full', 'mb-2');
    notificationDropdown.classList.add('top-full', 'mt-2');
    
    // Ajustar posición si está cerca del borde inferior
    const rect = notificationBtn.getBoundingClientRect();
    const dropdownHeight = notificationDropdown.offsetHeight;
    const spaceBelow = window.innerHeight - rect.bottom - dropdownHeight - 20; // 20px de margen
    
    if (spaceBelow < 0) {
        // Si no hay espacio, limitar la altura y hacer scrollable
        notificationDropdown.style.maxHeight = `${window.innerHeight - rect.bottom - 20}px`;
    } else {
        notificationDropdown.style.maxHeight = '24rem'; // 96 * 0.25rem = 24rem
    }
    
    // Forzar reflow para activar la transición
    void notificationDropdown.offsetWidth;
    
    // Mostrar dropdown con animación
    notificationDropdown.classList.remove('hidden', 'opacity-0', 'scale-95');
    notificationDropdown.classList.add('opacity-100', 'scale-100');
}
    
    function closeNotificationDropdown() {
        if (notificationDropdown.classList.contains('hidden')) return;
        
        // Animación de cierre suave
        notificationDropdown.classList.remove('opacity-100', 'scale-100');
        notificationDropdown.classList.add('opacity-0', 'scale-95');
        
        // Ocultar después de la animación
        setTimeout(() => {
            notificationDropdown.classList.add('hidden');
        }, 200);
    }
    
    // Dropdown de perfil
    function toggleProfileDropdown() {
        // Si ya está abierto, cerrarlo
        if (!profileDropdown.classList.contains('hidden')) {
            closeProfileDropdown();
            return;
        }
        
        // Cerrar otros dropdowns primero
        closeNotificationDropdown();
        
        // Forzar reflow para activar la transición
        void profileDropdown.offsetWidth;
        
        // Mostrar dropdown
        profileDropdown.classList.remove('hidden', 'opacity-0', 'scale-95');
        profileDropdown.classList.add('opacity-100', 'scale-100');
    }
    
    function closeProfileDropdown() {
        if (profileDropdown.classList.contains('hidden')) return;
        
        // Animación de cierre
        profileDropdown.classList.remove('opacity-100', 'scale-100');
        profileDropdown.classList.add('opacity-0', 'scale-95');
        
        // Ocultar después de la animación
        setTimeout(() => {
            profileDropdown.classList.add('hidden');
        }, 200);
    }
    
    // Event listeners para los dropdowns
    notificationBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        toggleNotificationDropdown();
    });
    
    profileDropdownBtn.addEventListener('click', function(e) {
        e.stopPropagation();
        toggleProfileDropdown();
    });
    
    // Cerrar dropdowns al hacer clic fuera
    document.addEventListener('click', function(e) {
        // Si el clic no fue en el botón de notificaciones ni en el dropdown
        if (!notificationBtn.contains(e.target) && !notificationDropdown.contains(e.target)) {
            closeNotificationDropdown();
        }
        
        // Si el clic no fue en el botón de perfil ni en el dropdown
        if (!profileDropdownBtn.contains(e.target) && !profileDropdown.contains(e.target)) {
            closeProfileDropdown();
        }
    });
    
    // Cerrar dropdowns al presionar Esc
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            closeAllDropdowns();
        }
    });
    
    // Hover effect for desktop sidebar
    if (window.innerWidth >= 1024) {
        sidebar.classList.add('group');
        
        // Show sidebar on hover
        sidebar.addEventListener('mouseenter', function() {
            this.classList.remove('lg:w-24', 'lg:w-20');
            this.classList.add('lg:w-72');
            centerIconsWhenCollapsed();
        });
        
        // Hide sidebar when mouse leaves
        sidebar.addEventListener('mouseleave', function() {
            this.classList.remove('lg:w-72');
            this.classList.add('lg:w-24');
            closeAllDropdowns();
            centerIconsWhenCollapsed();
        });
    }
    
    // Aplicar centrado inicial
    centerIconsWhenCollapsed();
    
    // Manejar cambios de tamaño de pantalla
    window.addEventListener('resize', function() {
        if (window.innerWidth >= 1024) {
            sidebar.classList.add('group');
            sidebar.classList.add('lg:w-24');
        } else {
            sidebar.classList.remove('group');
        }
        centerIconsWhenCollapsed();
    });
});

function showMessageModal(message, color = 'blue', icon = 'fa-info-circle') {
    // Crear contenedor si no existe
    let messagesContainer = document.getElementById('messages-container');
    if (!messagesContainer) {
        messagesContainer = document.createElement('div');
        messagesContainer.id = 'messages-container';
        messagesContainer.className = 'fixed top-4 right-4 z-50 space-y-2 w-full max-w-xs';
        document.body.appendChild(messagesContainer);
    }

    const modal = document.createElement('div');
    modal.className = `bg-${color}-500 text-white px-4 py-3 rounded shadow-lg flex items-center justify-between transform transition-all duration-300 translate-x-full`;
    
    modal.innerHTML = `
        <div class="flex items-center">
            <i class="fas ${icon} mr-2"></i>
            <span class="text-sm">${message}</span>
        </div>
        <button onclick="this.parentElement.remove()" class="ml-2">
            <i class="fas fa-times"></i>
        </button>
    `;
    
    messagesContainer.appendChild(modal);
    
    // Animación de entrada
    setTimeout(() => {
        modal.classList.remove('translate-x-full');
        modal.classList.add('translate-x-0');
    }, 10);
    
    // Animación de salida y eliminación después de 3 segundos
    setTimeout(() => {
        modal.classList.remove('translate-x-0');
        modal.classList.add('translate-x-full');
        
        // Eliminar después de la animación
        setTimeout(() => {
            modal.remove();
            // Eliminar contenedor si no hay más mensajes
            if (messagesContainer.children.length === 0) {
                messagesContainer.remove();
            }
        }, 300);
    }, 3000);
}

// Función para eliminar notificación individual
window.deleteNotification = function(event, notificationId) {
    event.preventDefault();
    event.stopPropagation();
    
    const notificationItem = event.target.closest('.notification-item');
    
    // Mostrar modal de confirmación
    const confirmModal = document.createElement('div');
    confirmModal.id = 'confirmDeleteModal';
    confirmModal.className = 'fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50';
    confirmModal.innerHTML = `
        <div class="bg-white rounded-lg p-6 max-w-sm w-full mx-4">
            <div class="text-red-500 mb-4 text-center">
                <i class="fas fa-exclamation-triangle text-4xl"></i>
            </div>
            <h3 class="text-lg font-medium text-gray-900 mb-2 text-center">¿Eliminar esta notificación?</h3>
            <p class="text-sm text-gray-500 mb-4 text-center">Esta acción no se puede deshacer.</p>
            <div class="flex justify-center space-x-4">
                <button id="confirmDelete" class="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600 transition">Eliminar</button>
                <button id="cancelDelete" class="px-4 py-2 bg-gray-300 text-gray-700 rounded hover:bg-gray-400 transition">Cancelar</button>
            </div>
        </div>
    `;
    document.body.appendChild(confirmModal);
    
    document.getElementById('confirmDelete').addEventListener('click', function() {
        fetch('../admin/includes/eliminar_notificacion.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ id: notificationId })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                confirmModal.remove();
                notificationItem.remove();
                
                // Actualizar el contador de notificaciones
                updateNotificationCounter();
                
                // Mostrar mensaje de éxito
                showMessageModal('Notificación eliminada correctamente', 'green');

                // 2. Redireccionar después de 1.5 segundos (para que se vea el mensaje)
            setTimeout(() => {
                location.reload();
            }, 1500);
                
                // Verificar si quedan notificaciones
                const notificationsContainer = document.querySelector('.notifications-container');
                const notificationItems = notificationsContainer.querySelectorAll('.notification-item');
                
                if (notificationItems.length === 0) {
                    notificationsContainer.innerHTML = `
                        <div class="px-4 py-6 text-center">
                            <i class="fas fa-bell-slash text-gray-300 text-2xl mb-2"></i>
                            <p class="text-sm text-gray-500">No hay notificaciones nuevas</p>
                        </div>
                    `;
                }
            } else {
                showMessageModal(data.message || 'Error al eliminar notificación', 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showMessageModal('Error al eliminar notificación', 'error');
        });
    });
    
    document.getElementById('cancelDelete').addEventListener('click', function() {
        confirmModal.remove();
    });
};

// Marcar todas las notificaciones como leídas
document.getElementById('mark-all-read')?.addEventListener('click', function(e) {
    e.preventDefault();

    if (this.disabled) {
        e.preventDefault();
        e.stopPropagation();
        return false;
    }

    fetch('../admin/includes/marcar_notificaciones_leidas.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Cambiar visualmente el estado
            document.querySelectorAll('.notification-item').forEach(item => {
                item.classList.remove('bg-white');
                item.classList.add('bg-gray-200');
            });
            
            // Actualizar el contador inmediatamente
            updateNotificationCounter();
            
            // Mostrar confirmación con fondo azul
            showMessageModal('Todas las notificaciones han sido marcadas como leídas', 'green', 'fa-check-circle');
            
            // Recargar después de 1.5 segundos para sincronización completa
            setTimeout(() => {
                location.reload();
            }, 1500);
        } else {
            showMessageModal(data.message || 'Error al marcar notificaciones', 'red', 'fa-exclamation-circle');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showMessageModal('Error al marcar notificaciones', 'red', 'fa-exclamation-circle');
    });
});

// Eliminar todas las notificaciones
document.getElementById('delete-all-notifications')?.addEventListener('click', function(e) {
    e.preventDefault();

    if (this.disabled) {
        e.preventDefault();
        e.stopPropagation();
        return false;
    }
    
    // Mostrar modal de confirmación
    const confirmModal = document.createElement('div');
    confirmModal.id = 'confirmDeleteAllModal';
    confirmModal.className = 'fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50';
    confirmModal.innerHTML = `
        <div class="bg-white rounded-lg p-6 max-w-sm w-full mx-4">
            <div class="text-red-500 mb-4 text-center">
                <i class="fas fa-exclamation-triangle text-4xl"></i>
            </div>
            <h3 class="text-lg font-medium text-gray-900 mb-2 text-center">¿Eliminar todas las notificaciones?</h3>
            <p class="text-sm text-gray-500 mb-4 text-center">Esta acción no se puede deshacer.</p>
            <div class="flex justify-center space-x-4">
                <button id="confirmDeleteAll" class="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600 transition">Eliminar</button>
                <button id="cancelDeleteAll" class="px-4 py-2 bg-gray-300 text-gray-700 rounded hover:bg-gray-400 transition">Cancelar</button>
            </div>
        </div>
    `;
    document.body.appendChild(confirmModal);
    
document.getElementById('confirmDeleteAll').addEventListener('click', function() {
    fetch('../admin/includes/eliminar_notificaciones.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            confirmModal.remove();
            
            // Mostrar mensaje con fondo rojo
            showMessageModal('Todas las notificaciones han sido eliminadas', 'red', 'fa-trash-alt');
            
            // Actualizar visualmente
            const notificationsContainer = document.querySelector('.notifications-container');
            notificationsContainer.innerHTML = `
                <div class="px-4 py-6 text-center">
                    <i class="fas fa-bell-slash text-gray-300 text-2xl mb-2"></i>
                    <p class="text-sm text-gray-500">No hay notificaciones nuevas</p>
                </div>
            `;
            
            // Actualizar el contador
            updateNotificationCounter();
            
            // Redirigir después de 1.5 segundos
            setTimeout(() => {
                location.reload();
            }, 1500);
        } else {
            showMessageModal(data.message || 'Error al eliminar notificaciones', 'red', 'fa-exclamation-circle');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showMessageModal('Error al eliminar notificaciones', 'red', 'fa-exclamation-circle');
    });
});
    
    document.getElementById('cancelDeleteAll').addEventListener('click', function() {
        confirmModal.remove();
    });
});

// Función mejorada para actualizar el contador
function updateNotificationCounter() {
    fetch('../admin/includes/marcar_notificaciones_no_leidas.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const badge = document.querySelector('.notification-btn .notification-badge');
                const counter = data.count > 0 ? data.count : '';
                
                // Actualizar o crear el badge
                if (badge) {
                    if (data.count > 0) {
                        badge.textContent = counter;
                        badge.classList.remove('hidden');
                    } else {
                        badge.textContent = '';
                        badge.classList.add('hidden');
                    }
                } else if (data.count > 0) {
                    const newBadge = document.createElement('span');
                    newBadge.className = 'notification-badge absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center animate-pulse';
                    newBadge.textContent = data.count;
                    document.querySelector('.notification-btn').appendChild(newBadge);
                }
            }
        })
        .catch(error => {
            console.error('Error al actualizar contador:', error);
        });
}

        // Manejar acciones de usuario
document.addEventListener('DOMContentLoaded', function() {
    // Variables para la acción actual
    let currentAction = null;
    let currentUserId = null;
    
    // Configurar modales para acciones
    const actionModal = document.getElementById('action-modal');
    const confirmBtn = document.getElementById('confirm-action');
    const cancelBtn = document.getElementById('cancel-action');
    const modalTitle = document.getElementById('modal-title');
    const modalMessage = document.getElementById('modal-message');
    const modalHeader = document.querySelector('#action-modal .bg-white .px-4.pt-5.pb-4');
    
    // Modal de edición
    const editModal = document.getElementById('edit-user-modal');
    const editForm = document.getElementById('edit-user-form');
    const cancelEditBtn = document.getElementById('cancel-edit-user');
    
    // Función para abrir el modal de edición con animación
function openEditModal() {
    const modal = document.getElementById('edit-user-modal');
    const modalBackdrop = document.getElementById('edit-modal-backdrop');
    const modalContent = document.getElementById('edit-modal-content');
    
    modal.classList.remove('hidden');
    
    // Forzar reflow para activar la transición
    void modal.offsetWidth;
    
    // Animaciones
    modalBackdrop.classList.remove('opacity-0');
    modalBackdrop.classList.add('opacity-75');
    
    modalContent.classList.remove('opacity-0', 'translate-y-4', 'sm:scale-95');
    modalContent.classList.add('opacity-100', 'translate-y-0', 'sm:scale-100');
}

// Función para cerrar el modal de edición con animación
function closeEditModal() {
    const modal = document.getElementById('edit-user-modal');
    const modalBackdrop = document.getElementById('edit-modal-backdrop');
    const modalContent = document.getElementById('edit-modal-content');
    
    // Animaciones de salida
    modalBackdrop.classList.remove('opacity-75');
    modalBackdrop.classList.add('opacity-0');
    
    modalContent.classList.remove('opacity-100', 'translate-y-0', 'sm:scale-100');
    modalContent.classList.add('opacity-0', 'translate-y-4', 'sm:scale-95');
    
    // Esperar a que termine la animación antes de ocultar
    setTimeout(() => {
        modal.classList.add('hidden');
    }, 300);
}

document.querySelectorAll('.edit-user').forEach(btn => {
    btn.addEventListener('click', function() {
        const userId = this.getAttribute('data-id');
        currentUserId = userId;
        
        // Obtener datos del usuario
        fetch(`../admin/includes/obtener_usuario.php?cedula=${userId}`)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    const nombreInput = document.getElementById('edit-nombre');
                    const apellidoInput = document.getElementById('edit-apellido');
                    const emailInput = document.getElementById('edit-email');
                    const rolSelect = document.getElementById('edit-rol');
                    
                    // Establecer valores
                    nombreInput.value = data.usuario.nombre;
                    nombreInput.defaultValue = data.usuario.nombre;
                    apellidoInput.value = data.usuario.apellido;
                    apellidoInput.defaultValue = data.usuario.apellido;
                    emailInput.value = data.usuario.email;
                    emailInput.defaultValue = data.usuario.email;
                    rolSelect.value = data.usuario.id_rol;
                    rolSelect.defaultValue = data.usuario.id_rol;
                    
                    document.getElementById('edit-cedula').value = data.usuario.cedula;
                    
                    openEditModal();
                } else {
                    showMessageModal(data.message || 'Error al cargar usuario', 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showMessageModal('Error al cargar usuario', 'error');
            });
    });
});

// Cerrar al hacer clic en el botón de cancelar
document.getElementById('cancel-edit-user').addEventListener('click', closeEditModal);

// Cerrar al hacer clic fuera del contenido del modal
document.getElementById('edit-modal-backdrop').addEventListener('click', closeEditModal);

// Prevenir que el clic en el contenido del modal lo cierre
document.getElementById('edit-modal-content').addEventListener('click', function(e) {
    e.stopPropagation();
});
    
// Botones de bloquear
document.querySelectorAll('.block-user').forEach(btn => {
    btn.addEventListener('click', function() {
        currentUserId = this.getAttribute('data-id');
        currentAction = 'block';
        
        const confirmModal = document.createElement('div');
        confirmModal.id = 'confirmActionModal';
        confirmModal.className = 'fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50';
        confirmModal.innerHTML = `
            <div class="bg-white rounded-lg p-6 max-w-sm w-full mx-4">
                <div class="text-red-500 mb-4 text-center">
                    <i class="fas fa-exclamation-triangle text-4xl"></i>
                </div>
                <h3 class="text-lg font-medium text-gray-900 mb-2 text-center">¿Bloquear este usuario?</h3>
                <p class="text-sm text-gray-500 mb-4 text-center">El usuario no podrá iniciar sesión hasta que sea desbloqueado.</p>
                <div class="flex justify-center space-x-4">
                    <button id="confirmAction" class="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600 transition">Bloquear</button>
                    <button id="cancelAction" class="px-4 py-2 bg-gray-300 text-gray-700 rounded hover:bg-gray-400 transition">Cancelar</button>
                </div>
            </div>
        `;
        document.body.appendChild(confirmModal);
        
        document.getElementById('confirmAction').addEventListener('click', function() {
            confirmModal.remove();
            executeUserAction();
        });
        
        document.getElementById('cancelAction').addEventListener('click', function() {
            confirmModal.remove();
        });
    });
});

// Botones de desbloquear
document.querySelectorAll('.unblock-user').forEach(btn => {
    btn.addEventListener('click', function() {
        currentUserId = this.getAttribute('data-id');
        currentAction = 'unblock';
        
        const confirmModal = document.createElement('div');
        confirmModal.id = 'confirmActionModal';
        confirmModal.className = 'fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50';
        confirmModal.innerHTML = `
            <div class="bg-white rounded-lg p-6 max-w-sm w-full mx-4">
                <div class="text-green-500 mb-4 text-center">
                    <i class="fas fa-check-circle text-4xl"></i>
                </div>
                <h3 class="text-lg font-medium text-gray-900 mb-2 text-center">¿Desbloquear este usuario?</h3>
                <p class="text-sm text-gray-500 mb-4 text-center">El usuario podrá iniciar sesión nuevamente.</p>
                <div class="flex justify-center space-x-4">
                    <button id="confirmAction" class="px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600 transition">Desbloquear</button>
                    <button id="cancelAction" class="px-4 py-2 bg-gray-300 text-gray-700 rounded hover:bg-gray-400 transition">Cancelar</button>
                </div>
            </div>
        `;
        document.body.appendChild(confirmModal);
        
        document.getElementById('confirmAction').addEventListener('click', function() {
            confirmModal.remove();
            executeUserAction();
        });
        
        document.getElementById('cancelAction').addEventListener('click', function() {
            confirmModal.remove();
        });
    });
});
    
    // Botones de eliminar
document.querySelectorAll('.delete-user').forEach(btn => {
    btn.addEventListener('click', function() {
        currentUserId = this.getAttribute('data-id');
        currentAction = 'delete';
        
        const confirmModal = document.createElement('div');
        confirmModal.id = 'confirmDeleteModal';
        confirmModal.className = 'fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50';
        confirmModal.innerHTML = `
            <div class="bg-white rounded-lg p-6 max-w-sm w-full mx-4">
                <div class="text-red-500 mb-4 text-center">
                    <i class="fas fa-exclamation-triangle text-4xl"></i>
                </div>
                <h3 class="text-lg font-medium text-gray-900 mb-2 text-center">¿Eliminar este usuario?</h3>
                <p class="text-sm text-gray-500 mb-4 text-center">Esta acción no se puede deshacer.</p>
                <div class="flex justify-center space-x-4">
                    <button id="confirmDelete" class="px-4 py-2 bg-red-500 text-white rounded hover:bg-red-600 transition">Eliminar</button>
                    <button id="cancelDelete" class="px-4 py-2 bg-gray-300 text-gray-700 rounded hover:bg-gray-400 transition">Cancelar</button>
                </div>
            </div>
        `;
        document.body.appendChild(confirmModal);
        
        document.getElementById('confirmDelete').addEventListener('click', function() {
            confirmModal.remove();
            executeUserAction();
        });
        
        document.getElementById('cancelDelete').addEventListener('click', function() {
            confirmModal.remove();
        });
    });
});
    
function executeUserAction() {
    let endpoint = '';
    let data = { cedula: currentUserId };
    
    switch(currentAction) {
        case 'block':
            endpoint = '../admin/includes/bloquear_usuario.php';
            break;
        case 'unblock':
            endpoint = '../admin/includes/desbloquear_usuario.php';
            break;
        case 'delete':
            endpoint = '../admin/includes/eliminar_usuario.php';
            break;
    }
    
    fetch(endpoint, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Mostrar mensaje con color según la acción
            let bgColor = 'blue';
            let icon = 'fa-info-circle';
            
            if (currentAction === 'block') {
                bgColor = 'red';
                icon = 'fa-lock';
            } else if (currentAction === 'unblock') {
                bgColor = 'green';
                icon = 'fa-unlock';
            } else if (currentAction === 'delete') {
                bgColor = 'red';
                icon = 'fa-trash-alt';
            }
            
            showMessageModal(data.message, bgColor, icon);
            
            // Redirigir después de 1.5 segundos
            setTimeout(() => {
                window.location.href = 'usuarios.php';
            }, 1500);
        } else {
            showMessageModal(data.message || 'Ocurrió un error', 'red', 'fa-exclamation-circle');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showMessageModal('Error al procesar la solicitud', 'red', 'fa-exclamation-circle');
    });
}
    
    // Cancelar acción
    cancelBtn.addEventListener('click', function() {
        actionModal.classList.add('hidden');
        currentAction = null;
        currentUserId = null;
        // Restaurar estado original del modal
    confirmBtn.classList.remove('hidden');
    cancelBtn.textContent = 'Cancelar';
    const modalHeader = document.querySelector('#action-modal .bg-white .px-4.pt-5.pb-4');
    modalHeader.className = 'bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4';
    confirmBtn.className = 'w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm';
    });
    
// Manejar envío del formulario de edición
editForm.addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Obtener valores originales y nuevos
    const originalValues = {
        nombre: document.getElementById('edit-nombre').defaultValue,
        apellido: document.getElementById('edit-apellido').defaultValue,
        email: document.getElementById('edit-email').defaultValue,
        rol: document.getElementById('edit-rol').defaultValue
    };
    
    const newValues = {
        nombre: document.getElementById('edit-nombre').value,
        apellido: document.getElementById('edit-apellido').value,
        email: document.getElementById('edit-email').value,
        rol: document.getElementById('edit-rol').value
    };
    
    // Verificar si hay cambios
    const hasChanges = JSON.stringify(originalValues) !== JSON.stringify(newValues);
    
    if (!hasChanges) {
        showMessageModal('No se realizaron cambios. Edita la información para guardar.', 'info');
        return;
    }
    
    const formData = new FormData(this);
    const data = Object.fromEntries(formData.entries());
    
    fetch('../admin/includes/editar_usuario.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Cerrar modal de edición
            closeEditModal();
            
            // Mostrar notificación de éxito
            showMessageModal(data.message || 'Cambios guardados correctamente', 'success');
            
            // Redirigir después de que desaparezca el mensaje (3 segundos)
            setTimeout(() => {
                window.location.href = 'usuarios.php';
            }, 3000);
        } else {
            // Mostrar notificación de error
            showMessageModal(data.message || 'Error al actualizar usuario', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showMessageModal('Error al procesar la solicitud', 'error');
    });
});

// Cancelar edición
cancelEditBtn.addEventListener('click', function() {
    editModal.classList.add('hidden');
});

});

// Filtrar usuarios
document.getElementById('filter-form').addEventListener('submit', function(e) {
    e.preventDefault();

    const formData = new FormData(this);
    const params = new URLSearchParams();

    for (const [key, value] of formData.entries()) {
        if (value) {
            params.append(key, value);
        }
    }

    // Redirige a la misma página con los parámetros
    window.location.href = window.location.pathname + '?' + params.toString();
});

// Variables para controlar el modal
let modal = document.getElementById('add-user-modal');
let modalBackdrop = document.getElementById('modal-backdrop');
let modalContent = document.getElementById('modal-content');

// Función para abrir el modal con animación
function openModal() {
    modal.classList.remove('hidden');
    
    // Forzar reflow para activar la transición
    void modal.offsetWidth;
    
    // Animaciones
    modalBackdrop.classList.remove('opacity-0');
    modalBackdrop.classList.add('opacity-100');
    
    modalContent.classList.remove('opacity-0', 'translate-y-4', 'sm:scale-95');
    modalContent.classList.add('opacity-100', 'translate-y-0', 'sm:scale-100');
}

// Función para cerrar el modal con animación
function closeModal() {
    // Animaciones de salida
    modalBackdrop.classList.remove('opacity-100');
    modalBackdrop.classList.add('opacity-0');
    
    modalContent.classList.remove('opacity-100', 'translate-y-0', 'sm:scale-100');
    modalContent.classList.add('opacity-0', 'translate-y-4', 'sm:scale-95');
    
    // Esperar a que termine la animación antes de ocultar
    setTimeout(() => {
        modal.classList.add('hidden');
        document.getElementById('add-user-form').reset();
    }, 300);
}

// Event listeners
document.getElementById('add-user-btn').addEventListener('click', openModal);

document.getElementById('cancel-add-user').addEventListener('click', closeModal);

// Cerrar al hacer clic fuera del contenido del modal
modalBackdrop.addEventListener('click', closeModal);

// Prevenir que el clic en el contenido del modal lo cierre
modalContent.addEventListener('click', function(e) {
    e.stopPropagation();
});

// Toggle para ver contraseña en el modal
document.getElementById('toggle-add-password').addEventListener('click', function() {
    const passwordInput = document.getElementById('add-password');
    const icon = this.querySelector('i');
    
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        icon.classList.replace('fa-eye', 'fa-eye-slash');
    } else {
        passwordInput.type = 'password';
        icon.classList.replace('fa-eye-slash', 'fa-eye');
    }
});

// Toggle para ver confirmación de contraseña en el modal
document.getElementById('toggle-add-confirm-password').addEventListener('click', function() {
    const confirmPasswordInput = document.getElementById('add-confirm-password');
    const icon = this.querySelector('i');
    
    if (confirmPasswordInput.type === 'password') {
        confirmPasswordInput.type = 'text';
        icon.classList.replace('fa-eye', 'fa-eye-slash');
    } else {
        confirmPasswordInput.type = 'password';
        icon.classList.replace('fa-eye-slash', 'fa-eye');
    }
});

// Manejar envío del formulario de registro
document.getElementById('add-user-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const password = document.getElementById('add-password').value;
    const confirmPassword = document.getElementById('add-confirm-password').value;
    
    if (password !== confirmPassword) {
        showMessageModal('Las contraseñas no coinciden', 'error');
        return;
    }
    
    const formData = new FormData(this);
    formData.append('id_rol', document.getElementById('add-rol').value);
    
    fetch('../admin/includes/register_admin.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Mostrar modal de éxito
            document.getElementById('add-user-modal').classList.add('hidden');
            document.getElementById('add-user-form').reset();
            
            showMessageModal(data.message, 'success');
            
            // Recargar después de 1.5 segundos
            setTimeout(() => {
                location.reload();
            }, 1500);
        } else {
            showMessageModal(data.message || 'Error al registrar el usuario', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showMessageModal('Error al registrar el usuario', 'error');
    });
});


// Función para abrir el modal de producto con animación
function openProductModal() {
    const modal = document.getElementById('add-product-modal');
    const modalBackdrop = document.getElementById('product-modal-backdrop');
    const modalContent = document.getElementById('product-modal-content');
    
    modal.classList.remove('hidden');
    
    // Forzar reflow para activar la transición
    void modal.offsetWidth;
    
    // Animaciones
    modalBackdrop.classList.remove('opacity-0');
    modalBackdrop.classList.add('opacity-75');
    
    modalContent.classList.remove('opacity-0', 'translate-y-4', 'sm:scale-95');
    modalContent.classList.add('opacity-100', 'translate-y-0', 'sm:scale-100');
}

// Función para cerrar el modal de producto con animación
function closeProductModal() {
    const modal = document.getElementById('add-product-modal');
    const modalBackdrop = document.getElementById('product-modal-backdrop');
    const modalContent = document.getElementById('product-modal-content');
    
    // Animaciones de salida
    modalBackdrop.classList.remove('opacity-75');
    modalBackdrop.classList.add('opacity-0');
    
    modalContent.classList.remove('opacity-100', 'translate-y-0', 'sm:scale-100');
    modalContent.classList.add('opacity-0', 'translate-y-4', 'sm:scale-95');
    
    // Esperar a que termine la animación antes de ocultar
    setTimeout(() => {
        modal.classList.add('hidden');
        document.getElementById('add-product-form').reset();
    }, 300);
}

// Función para abrir el modal de categoría con animación
function openCategoryModal() {
    const modal = document.getElementById('add-category-modal');
    const modalBackdrop = document.getElementById('category-modal-backdrop');
    const modalContent = document.getElementById('category-modal-content');
    
    modal.classList.remove('hidden');
    
    // Forzar reflow para activar la transición
    void modal.offsetWidth;
    
    // Animaciones
    modalBackdrop.classList.remove('opacity-0');
    modalBackdrop.classList.add('opacity-75');
    
    modalContent.classList.remove('opacity-0', 'translate-y-4', 'sm:scale-95');
    modalContent.classList.add('opacity-100', 'translate-y-0', 'sm:scale-100');
}

// Función para cerrar el modal de categoría con animación
function closeCategoryModal() {
    const modal = document.getElementById('add-category-modal');
    const modalBackdrop = document.getElementById('category-modal-backdrop');
    const modalContent = document.getElementById('category-modal-content');
    
    // Animaciones de salida
    modalBackdrop.classList.remove('opacity-75');
    modalBackdrop.classList.add('opacity-0');
    
    modalContent.classList.remove('opacity-100', 'translate-y-0', 'sm:scale-100');
    modalContent.classList.add('opacity-0', 'translate-y-4', 'sm:scale-95');
    
    // Esperar a que termine la animación antes de ocultar
    setTimeout(() => {
        modal.classList.add('hidden');
        document.getElementById('add-category-form').reset();
    }, 300);
}

// Función para abrir el modal de oferta con animación
function openOfferModal() {
    const modal = document.getElementById('add-offer-modal');
    const modalBackdrop = document.getElementById('offer-modal-backdrop');
    const modalContent = document.getElementById('offer-modal-content');
    
    modal.classList.remove('hidden');
    
    // Forzar reflow para activar la transición
    void modal.offsetWidth;
    
    // Animaciones
    modalBackdrop.classList.remove('opacity-0');
    modalBackdrop.classList.add('opacity-75');
    
    modalContent.classList.remove('opacity-0', 'translate-y-4', 'sm:scale-95');
    modalContent.classList.add('opacity-100', 'translate-y-0', 'sm:scale-100');
}

// Función para cerrar el modal de oferta con animación
function closeOfferModal() {
    const modal = document.getElementById('add-offer-modal');
    const modalBackdrop = document.getElementById('offer-modal-backdrop');
    const modalContent = document.getElementById('offer-modal-content');
    
    // Animaciones de salida
    modalBackdrop.classList.remove('opacity-75');
    modalBackdrop.classList.add('opacity-0');
    
    modalContent.classList.remove('opacity-100', 'translate-y-0', 'sm:scale-100');
    modalContent.classList.add('opacity-0', 'translate-y-4', 'sm:scale-95');
    
    // Esperar a que termine la animación antes de ocultar
    setTimeout(() => {
        modal.classList.add('hidden');
        document.getElementById('add-offer-form').reset();
    }, 300);
}

// Función para abrir el modal de edición de producto con animación
function openEditProductModal() {
    const modal = document.getElementById('edit-product-modal');
    const modalBackdrop = document.getElementById('edit-product-backdrop');
    const modalContent = document.getElementById('edit-product-content');
    
    modal.classList.remove('hidden');
    
    // Forzar reflow para activar la transición
    void modal.offsetWidth;
    
    // Animaciones
    modalBackdrop.classList.remove('opacity-0');
    modalBackdrop.classList.add('opacity-75');
    
    modalContent.classList.remove('opacity-0', 'translate-y-4', 'sm:scale-95');
    modalContent.classList.add('opacity-100', 'translate-y-0', 'sm:scale-100');
}

// Función para cerrar el modal de edición de producto con animación
function closeEditProductModal() {
    const modal = document.getElementById('edit-product-modal');
    const modalBackdrop = document.getElementById('edit-product-backdrop');
    const modalContent = document.getElementById('edit-product-content');
    
    // Animaciones de salida
    modalBackdrop.classList.remove('opacity-75');
    modalBackdrop.classList.add('opacity-0');
    
    modalContent.classList.remove('opacity-100', 'translate-y-0', 'sm:scale-100');
    modalContent.classList.add('opacity-0', 'translate-y-4', 'sm:scale-95');
    
    // Esperar a que termine la animación antes de ocultar
    setTimeout(() => {
        modal.classList.add('hidden');
        document.getElementById('edit-product-form').reset();
    }, 300);
}

// Event listeners para los botones de abrir modal
document.getElementById('add-product-btn')?.addEventListener('click', openProductModal);
document.getElementById('add-category-btn')?.addEventListener('click', openCategoryModal);
document.getElementById('add-offer-btn')?.addEventListener('click', openOfferModal);

// Event listeners para los botones de cerrar modal
document.getElementById('close-add-product-modal')?.addEventListener('click', closeProductModal);
document.getElementById('close-add-category-modal')?.addEventListener('click', closeCategoryModal);
document.getElementById('close-add-offer-modal')?.addEventListener('click', closeOfferModal);
document.getElementById('close-edit-product-modal')?.addEventListener('click', closeEditProductModal);

// Event listeners para cerrar al hacer clic fuera del contenido del modal
document.getElementById('product-modal-backdrop')?.addEventListener('click', closeProductModal);
document.getElementById('category-modal-backdrop')?.addEventListener('click', closeCategoryModal);
document.getElementById('offer-modal-backdrop')?.addEventListener('click', closeOfferModal);
document.getElementById('edit-product-backdrop')?.addEventListener('click', closeEditProductModal);

// Prevenir que el clic en el contenido del modal lo cierre
document.getElementById('product-modal-content')?.addEventListener('click', function(e) {
    e.stopPropagation();
});
document.getElementById('category-modal-content')?.addEventListener('click', function(e) {
    e.stopPropagation();
});
document.getElementById('offer-modal-content')?.addEventListener('click', function(e) {
    e.stopPropagation();
});
document.getElementById('edit-product-content')?.addEventListener('click', function(e) {
    e.stopPropagation();
});

// Manejar el toggle de campos de oferta
document.getElementById('product-offer-check')?.addEventListener('change', function() {
    const offerFields = document.getElementById('offer-fields');
    if (this.checked) {
        offerFields.classList.remove('hidden');
    } else {
        offerFields.classList.add('hidden');
    }
});

document.getElementById('edit-product-offer-check')?.addEventListener('change', function() {
    const offerFields = document.getElementById('edit-offer-fields');
    if (this.checked) {
        offerFields.classList.remove('hidden');
    } else {
        offerFields.classList.add('hidden');
    }
});

// Manejar la vista previa de imagen para producto nuevo
document.getElementById('product-image-btn')?.addEventListener('click', function() {
    document.getElementById('product-image').click();
});

document.getElementById('product-image')?.addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(event) {
            const preview = document.getElementById('product-image-preview');
            preview.src = event.target.result;
            preview.classList.remove('hidden');
            document.getElementById('product-image-placeholder').classList.add('hidden');
        };
        reader.readAsDataURL(file);
    }
});

// Manejar la vista previa de imagen para edición de producto
document.getElementById('edit-product-image-btn')?.addEventListener('click', function() {
    document.getElementById('edit-product-image').click();
});

document.getElementById('edit-product-image')?.addEventListener('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(event) {
            document.getElementById('edit-product-image-preview').src = event.target.result;
        };
        reader.readAsDataURL(file);
    }
});

// Calcular precio con descuento
document.getElementById('product-discount')?.addEventListener('input', function() {
    const price = parseFloat(document.getElementById('product-price').value) || 0;
    const discount = parseFloat(this.value) || 0;
    const discountedPrice = price * (1 - discount / 100);
    document.getElementById('product-discounted-price').value = discountedPrice.toFixed(3);
});

document.getElementById('product-price')?.addEventListener('input', function() {
    const discount = parseFloat(document.getElementById('product-discount').value) || 0;
    if (discount > 0) {
        const price = parseFloat(this.value) || 0;
        const discountedPrice = price * (1 - discount / 100);
        document.getElementById('product-discounted-price').value = discountedPrice.toFixed(3);
    }
});

// Calcular precio con descuento para edición
document.getElementById('edit-product-discount')?.addEventListener('input', function() {
    const price = parseFloat(document.getElementById('edit-product-price').value) || 0;
    const discount = parseFloat(this.value) || 0;
    const discountedPrice = price * (1 - discount / 100);
    document.getElementById('edit-product-discounted-price').value = discountedPrice.toFixed(3);
});

document.getElementById('edit-product-price')?.addEventListener('input', function() {
    const discount = parseFloat(document.getElementById('edit-product-discount').value) || 0;
    if (discount > 0) {
        const price = parseFloat(this.value) || 0;
        const discountedPrice = price * (1 - discount / 100);
        document.getElementById('edit-product-discounted-price').value = discountedPrice.toFixed(3);
    }
});

// Manejar el envío del formulario de producto
document.getElementById('add-product-form')?.addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    
    fetch('../admin/includes/agregar_producto.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            closeProductModal();
            showMessageModal('Producto agregado exitosamente', 'green', 'fa-check-circle');
            
            // Recargar después de 1.5 segundos
            setTimeout(() => {
                location.reload();
            }, 1500);
        } else {
            showMessageModal(data.message || 'Error al agregar producto', 'red', 'fa-exclamation-circle');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showMessageModal('Error al agregar producto', 'red', 'fa-exclamation-circle');
    });
});

// Manejar el envío del formulario de categoría
document.getElementById('add-category-form')?.addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    
    fetch('../admin/includes/agregar_categoria.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            closeCategoryModal();
            showMessageModal('Categoría agregada exitosamente', 'green', 'fa-check-circle');
            
            // Recargar después de 1.5 segundos
            setTimeout(() => {
                location.reload();
            }, 1500);
        } else {
            showMessageModal(data.message || 'Error al agregar categoría', 'red', 'fa-exclamation-circle');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showMessageModal('Error al agregar categoría', 'red', 'fa-exclamation-circle');
    });
});

// Manejar el envío del formulario de oferta
document.getElementById('add-offer-form')?.addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    
    fetch('../admin/includes/agregar_oferta.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            closeOfferModal();
            showMessageModal('Oferta agregada exitosamente', 'green', 'fa-check-circle');
            
            // Recargar después de 1.5 segundos
            setTimeout(() => {
                location.reload();
            }, 1500);
        } else {
            showMessageModal(data.message || 'Error al agregar oferta', 'red', 'fa-exclamation-circle');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showMessageModal('Error al agregar oferta', 'red', 'fa-exclamation-circle');
    });
});

// Manejar el envío del formulario de edición de producto
document.getElementById('edit-product-form')?.addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData(this);
    
    fetch('../admin/includes/editar_producto.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            closeEditProductModal();
            showMessageModal('Producto actualizado exitosamente', 'green', 'fa-check-circle');
            
            // Recargar después de 1.5 segundos
            setTimeout(() => {
                location.reload();
            }, 1500);
        } else {
            showMessageModal(data.message || 'Error al actualizar producto', 'red', 'fa-exclamation-circle');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showMessageModal('Error al actualizar producto', 'red', 'fa-exclamation-circle');
    });
});

// Manejar el filtrado de productos
document.getElementById('filter-products-form')?.addEventListener('submit', function(e) {
    e.preventDefault();

    const formData = new FormData(this);
    const params = new URLSearchParams();

    for (const [key, value] of formData.entries()) {
        if (value) {
            params.append(key, value);
        }
    }

    // Redirige a la misma página con los parámetros
    window.location.href = window.location.pathname + '?' + params.toString();
});

// Cargar datos del producto para edición
document.querySelectorAll('.edit-product').forEach(btn => {
    btn.addEventListener('click', function() {
        const productId = this.getAttribute('data-id');
        
        // Obtener datos del producto
        fetch(`../admin/includes/obtener_producto.php?id=${productId}`)
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Establecer valores en el formulario de edición
                    document.getElementById('edit-product-id').value = data.producto.id_producto;
                    document.getElementById('edit-product-name').value = data.producto.nombre;
                    document.getElementById('edit-product-brand').value = data.producto.marca;
                    document.getElementById('edit-product-category').value = data.producto.id_categoria;
                    document.getElementById('edit-product-price').value = data.producto.precio;
                    document.getElementById('edit-product-stock').value = data.producto.stock;
                    document.getElementById('edit-product-description').value = data.producto.descripcion;
                    
                    if (data.producto.fecha_vencimiento) {
                        const fecha = new Date(data.producto.fecha_vencimiento);
                        const fechaFormateada = fecha.toISOString().split('T')[0];
                        document.getElementById('edit-product-expiration').value = fechaFormateada;
                    }
                    
                    if (data.producto.imagen) {
                        document.getElementById('edit-product-image-preview').src = data.producto.imagen;
                    }
                    
                    // Manejar oferta
                    const offerCheck = document.getElementById('edit-product-offer-check');
                    const offerFields = document.getElementById('edit-offer-fields');
                    if (data.producto.es_oferta) {
                        offerCheck.checked = true;
                        offerFields.classList.remove('hidden');
                        document.getElementById('edit-product-discount').value = data.producto.descuento;
                        document.getElementById('edit-product-discounted-price').value = data.producto.precio_descuento;
                    } else {
                        offerCheck.checked = false;
                        offerFields.classList.add('hidden');
                    }
                    
                    // Abrir modal de edición
                    openEditProductModal();
                } else {
                    showMessageModal(data.message || 'Error al cargar producto', 'red', 'fa-exclamation-circle');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showMessageModal('Error al cargar producto', 'red', 'fa-exclamation-circle');
            });
    });
});