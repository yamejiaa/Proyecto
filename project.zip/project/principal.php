<?php
session_start();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MotoRepuestos Colombia</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
</head>
<body class="min-h-screen bg-gray-100">
    <!-- Barra de navegación -->
    <nav class="bg-gradient-to-r from-blue-600 to-purple-500 p-4 text-white shadow-lg sticky top-0 z-50">
        <div class="container mx-auto flex justify-between items-center">
            <div class="flex items-center space-x-4">
                <a href="principal.php" class="text-2xl font-bold flex items-center">
                    <i class="fas fa-motorcycle mr-2"></i>
                    <span>MotoRepuestos</span>
                </a>
            </div>
            
            <div class="flex items-center space-x-6">
                <a href="principal.php" class="hover:text-blue-200 transition duration-300">
                    <i class="fas fa-home mr-1"></i> Inicio
                </a>
                <a href="#" class="hover:text-blue-200 transition duration-300">
                    <i class="fas fa-search mr-1"></i> Buscar
                </a>
                <a href="#" class="hover:text-blue-200 transition duration-300">
                    <i class="fas fa-info-circle mr-1"></i> Nosotros
                </a>
                
                <!-- Dropdown del carrito -->
                <div class="relative" x-data="{ open: false }">
                    <button @click="open = !open" class="relative flex items-center hover:text-blue-200 transition duration-300">
                        <i class="fas fa-shopping-cart text-xl"></i>
                        <?php if (isset($_SESSION['carrito']) && count($_SESSION['carrito']) > 0): ?>
                            <span class="cart-badge"><?php echo count($_SESSION['carrito']); ?></span>
                        <?php endif; ?>
                    </button>
                    
                    <!-- Dropdown content -->
                    <div x-show="open" @click.away="open = false" 
                         class="absolute right-0 mt-2 w-80 bg-white rounded-md shadow-lg overflow-hidden z-50 transform transition-all duration-300 origin-top-right"
                         x-transition:enter="transition ease-out duration-200"
                         x-transition:enter-start="opacity-0 scale-95"
                         x-transition:enter-end="opacity-100 scale-100"
                         x-transition:leave="transition ease-in duration-150"
                         x-transition:leave-start="opacity-100 scale-100"
                         x-transition:leave-end="opacity-0 scale-95">
                        <div class="bg-gradient-to-r from-blue-600 to-purple-500 p-4 text-white">
                            <h3 class="text-lg font-semibold flex items-center">
                                <i class="fas fa-shopping-cart mr-2"></i> Mi Carrito
                            </h3>
                        </div>
                        
                        <div class="max-h-96 overflow-y-auto">
                            <?php if (!isset($_SESSION['carrito']) || empty($_SESSION['carrito'])): ?>
                                <div class="p-4 text-center text-gray-500">
                                    <i class="fas fa-shopping-cart text-3xl mb-2 text-gray-300"></i>
                                    <p>Tu carrito está vacío</p>
                                </div>
                            <?php else: ?>
                                <?php foreach ($_SESSION['carrito'] as $id => $item): ?>
                                    <div class="p-4 border-b border-gray-200 flex items-center">
                                        <img src="<?php echo htmlspecialchars($item['imagen']); ?>" alt="<?php echo htmlspecialchars($item['nombre']); ?>" 
                                             class="w-16 h-16 object-cover rounded-md mr-3">
                                        <div class="flex-1">
                                            <h4 class="font-medium text-gray-800"><?php echo htmlspecialchars($item['nombre']); ?></h4>
                                            <p class="text-blue-600 font-semibold">$<?php echo number_format($item['precio'], 0, ',', '.'); ?></p>
                                            
                                            <div class="flex items-center mt-2">
                                                <button onclick="actualizarCantidad(<?php echo $id; ?>, -1)" 
                                                        class="bg-gray-200 text-gray-700 px-2 py-1 rounded-l-md hover:bg-gray-300 transition duration-300">
                                                    <i class="fas fa-minus"></i>
                                                </button>
                                                <input type="number" id="cantidad-<?php echo $id; ?>" 
                                                       value="<?php echo $item['cantidad']; ?>" min="1" 
                                                       class="w-12 text-center border-t border-b border-gray-300 py-1">
                                                <button onclick="actualizarCantidad(<?php echo $id; ?>, 1)" 
                                                        class="bg-gray-200 text-gray-700 px-2 py-1 rounded-r-md hover:bg-gray-300 transition duration-300">
                                                    <i class="fas fa-plus"></i>
                                                </button>
                                                
                                                <button onclick="eliminarProducto(<?php echo $id; ?>)" 
                                                        class="ml-auto text-red-500 hover:text-red-700 transition duration-300">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                        
                        <?php if (isset($_SESSION['carrito']) && !empty($_SESSION['carrito'])): ?>
                            <div class="p-4 bg-gray-50 border-t border-gray-200">
                                <div class="flex justify-between mb-2">
                                    <span class="font-medium">Total:</span>
                                    <span class="font-bold text-blue-600">$<?php 
                                        $total = 0;
                                        foreach ($_SESSION['carrito'] as $item) {
                                            $total += $item['precio'] * $item['cantidad'];
                                        }
                                        echo number_format($total, 0, ',', '.'); 
                                    ?></span>
                                </div>
                                <a href="checkout.php" class="block w-full text-center bg-blue-600 hover:bg-blue-700 text-white py-2 rounded-md transition duration-300">
                                    <i class="fas fa-credit-card mr-2"></i> Pagar ahora
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Dropdown del usuario -->
                <div class="relative" x-data="{ open: false }">
                    <button @click="open = !open" class="flex items-center space-x-1 hover:text-blue-200 transition duration-300">
                        <?php if (isset($_SESSION['user_email'])): ?>
                            <div class="avatar bg-white text-blue-600 w-8 h-8 rounded-full flex items-center justify-center font-bold">
                                <?php echo strtoupper(substr($_SESSION['user_email'], 0, 1)); ?>
                            </div>
                        <?php else: ?>
                            <i class="fas fa-user-circle text-xl"></i>
                        <?php endif; ?>
                    </button>
                    
                    <div x-show="open" @click.away="open = false" 
                         class="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg overflow-hidden z-50 transform transition-all duration-300 origin-top-right"
                         x-transition:enter="transition ease-out duration-200"
                         x-transition:enter-start="opacity-0 scale-95"
                         x-transition:enter-end="opacity-100 scale-100"
                         x-transition:leave="transition ease-in duration-150"
                         x-transition:leave-start="opacity-100 scale-100"
                         x-transition:leave-end="opacity-0 scale-95">
                        <?php if (isset($_SESSION['user_email'])): ?>
                            <a href="perfil.php" class="block px-4 py-2 text-gray-800 hover:bg-blue-50 transition duration-300">
                                <i class="fas fa-user mr-2 text-blue-600"></i> Mi perfil
                            </a>
                            <a href="pedidos.php" class="block px-4 py-2 text-gray-800 hover:bg-blue-50 transition duration-300">
                                <i class="fas fa-clipboard-list mr-2 text-blue-600"></i> Mis pedidos
                            </a>
                            <form action="includes/logout.php" method="POST">
                                <button type="submit" class="w-full text-left px-4 py-2 text-gray-800 hover:bg-blue-50 transition duration-300">
                                    <i class="fas fa-sign-out-alt mr-2 text-blue-600"></i> Cerrar sesión
                                </button>
                            </form>
                        <?php else: ?>
                            <a href="login.php" class="block px-4 py-2 text-gray-800 hover:bg-blue-50 transition duration-300">
                                <i class="fas fa-sign-in-alt mr-2 text-blue-600"></i> Iniciar sesión
                            </a>
                            <a href="register.php" class="block px-4 py-2 text-gray-800 hover:bg-blue-50 transition duration-300">
                                <i class="fas fa-user-plus mr-2 text-blue-600"></i> Registrarse
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <!-- Contenido principal -->
    <main class="container mx-auto p-4 mt-8">
        <!-- Filtros y búsqueda -->
        <div class="bg-white rounded-lg shadow-md p-4 mb-6">
            <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                <div class="relative flex-1">
                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <i class="fas fa-search text-gray-400"></i>
                    </div>
                    <input type="text" placeholder="Buscar repuestos..." 
                           class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-300">
                </div>
                
                <div class="flex flex-wrap gap-2">
                    <select class="border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-300">
                        <option>Todas las categorías</option>
                        <option>Motor</option>
                        <option>Frenos</option>
                        <option>Suspensión</option>
                        <option>Eléctrico</option>
                        <option>Accesorios</option>
                    </select>
                    
                    <select class="border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-300">
                        <option>Ordenar por</option>
                        <option>Menor precio</option>
                        <option>Mayor precio</option>
                        <option>Nombre A-Z</option>
                        <option>Nombre Z-A</option>
                    </select>
                </div>
            </div>
        </div>
        
        <!-- Productos -->
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            <!-- Ejemplo de producto 1 -->
            <div class="bg-white rounded-lg shadow-md overflow-hidden transition-all duration-300 producto-hover">
                <div class="relative">
                    <img src="https://via.placeholder.com/300x200?text=Repuesto+Moto" alt="Repuesto de moto" 
                         class="w-full h-48 object-cover">
                    <span class="absolute top-2 right-2 bg-red-500 text-white text-xs font-bold px-2 py-1 rounded-full">
                        -15%
                    </span>
                </div>
                
                <div class="p-4">
                    <h3 class="font-semibold text-lg mb-1 text-gray-800">Kit de Cadena</h3>
                    <p class="text-sm text-gray-600 mb-2">Marca XYZ</p>
                    
                    <div class="flex items-center mb-3">
                        <i class="fas fa-star text-yellow-400"></i>
                        <i class="fas fa-star text-yellow-400"></i>
                        <i class="fas fa-star text-yellow-400"></i>
                        <i class="fas fa-star text-yellow-400"></i>
                        <i class="fas fa-star-half-alt text-yellow-400"></i>
                        <span class="text-xs text-gray-500 ml-1">(4.5)</span>
                    </div>
                    
                    <div class="flex items-center justify-between">
                        <div>
                            <span class="text-gray-400 line-through text-sm mr-2">
                                $120.000
                            </span>
                            <span class="text-blue-600 font-bold">
                                $102.000
                            </span>
                        </div>
                        
                        <button onclick="agregarAlCarrito(1)" 
                                class="bg-blue-600 hover:bg-blue-700 text-white p-2 rounded-full transition duration-300">
                            <i class="fas fa-cart-plus"></i>
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- Ejemplo de producto 2 -->
            <div class="bg-white rounded-lg shadow-md overflow-hidden transition-all duration-300 producto-hover">
                <div class="relative">
                    <img src="https://via.placeholder.com/300x200?text=Pastillas+Freno" alt="Pastillas de freno" 
                         class="w-full h-48 object-cover">
                </div>
                
                <div class="p-4">
                    <h3 class="font-semibold text-lg mb-1 text-gray-800">Pastillas de Freno</h3>
                    <p class="text-sm text-gray-600 mb-2">Marca ABC</p>
                    
                    <div class="flex items-center mb-3">
                        <i class="fas fa-star text-yellow-400"></i>
                        <i class="fas fa-star text-yellow-400"></i>
                        <i class="fas fa-star text-yellow-400"></i>
                        <i class="fas fa-star text-yellow-400"></i>
                        <i class="far fa-star text-yellow-400"></i>
                        <span class="text-xs text-gray-500 ml-1">(4.0)</span>
                    </div>
                    
                    <div class="flex items-center justify-between">
                        <div>
                            <span class="text-blue-600 font-bold">
                                $85.000
                            </span>
                        </div>
                        
                        <button onclick="agregarAlCarrito(2)" 
                                class="bg-blue-600 hover:bg-blue-700 text-white p-2 rounded-full transition duration-300">
                            <i class="fas fa-cart-plus"></i>
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- Más productos... -->
        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-gradient-to-r from-blue-600 to-purple-500 text-white mt-12">
        <div class="container mx-auto py-8 px-4">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div>
                    <h3 class="text-xl font-bold mb-4 flex items-center">
                        <i class="fas fa-motorcycle mr-2"></i> MotoRepuestos
                    </h3>
                    <p class="text-blue-100">Tu tienda confiable de repuestos para motocicletas en Colombia. Calidad y garantía en cada producto.</p>
                </div>
                
                <div>
                    <h4 class="font-semibold mb-4">Enlaces útiles</h4>
                    <ul class="space-y-2">
                        <li><a href="#" class="text-blue-100 hover:text-white transition duration-300">Inicio</a></li>
                        <li><a href="#" class="text-blue-100 hover:text-white transition duration-300">Productos</a></li>
                        <li><a href="#" class="text-blue-100 hover:text-white transition duration-300">Nosotros</a></li>
                        <li><a href="#" class="text-blue-100 hover:text-white transition duration-300">Contacto</a></li>
                    </ul>
                </div>
                
                <div>
                    <h4 class="font-semibold mb-4">Contacto</h4>
                    <ul class="space-y-2">
                        <li class="flex items-center">
                            <i class="fas fa-map-marker-alt mr-2 text-blue-200"></i>
                            <span class="text-blue-100">Calle 123 #45-67, Bogotá</span>
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-phone-alt mr-2 text-blue-200"></i>
                            <span class="text-blue-100">+57 123 456 7890</span>
                        </li>
                        <li class="flex items-center">
                            <i class="fas fa-envelope mr-2 text-blue-200"></i>
                            <span class="text-blue-100">contacto@motorepuestos.com</span>
                        </li>
                    </ul>
                </div>
                
                <div>
                    <h4 class="font-semibold mb-4">Redes sociales</h4>
                    <div class="flex space-x-4">
                        <a href="#" class="text-blue-100 hover:text-white text-xl transition duration-300">
                            <i class="fab fa-facebook"></i>
                        </a>
                        <a href="#" class="text-blue-100 hover:text-white text-xl transition duration-300">
                            <i class="fab fa-instagram"></i>
                        </a>
                        <a href="#" class="text-blue-100 hover:text-white text-xl transition duration-300">
                            <i class="fab fa-twitter"></i>
                        </a>
                        <a href="#" class="text-blue-100 hover:text-white text-xl transition duration-300">
                            <i class="fab fa-whatsapp"></i>
                        </a>
                    </div>
                    
                    <h4 class="font-semibold mt-6 mb-2">Métodos de pago</h4>
                    <div class="flex flex-wrap gap-2">
                        <i class="fab fa-cc-visa text-2xl text-blue-100"></i>
                        <i class="fab fa-cc-mastercard text-2xl text-blue-100"></i>
                        <i class="fab fa-cc-amex text-2xl text-blue-100"></i>
                        <i class="fas fa-money-bill-wave text-2xl text-blue-100"></i>
                    </div>
                </div>
            </div>
            
            <div class="border-t border-blue-400 mt-8 pt-6 text-center text-blue-100">
                <p>&copy; <?php echo date('Y'); ?> MotoRepuestos Colombia. Todos los derechos reservados.</p>
            </div>
        </div>
    </footer>

    <!-- Modal de inicio de sesión requerido -->
    <div id="loginModal" class="fixed inset-0 z-50 flex items-center justify-center hidden">
        <div class="absolute inset-0 bg-black bg-opacity-50"></div>
        
        <div class="bg-white rounded-lg shadow-2xl overflow-hidden w-full max-w-md transform transition-all duration-500 relative z-10">
            <div class="bg-gradient-to-r from-blue-600 to-purple-500 p-6 text-white">
                <h1 class="text-2xl font-bold flex items-center gap-2 justify-center">
                    <i class="fas fa-exclamation-circle animate-pulse"></i> Acceso requerido
                </h1>
            </div>
            
            <div class="p-6 text-center">
                <p class="text-gray-700 mb-6">Debes iniciar sesión para agregar productos al carrito.</p>
                
                <div class="flex justify-center space-x-4">
                    <a href="login.php" class="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-md transition duration-300">
                        <i class="fas fa-sign-in-alt mr-2"></i> Iniciar sesión
                    </a>
                    <button onclick="cerrarModal()" class="bg-gray-200 hover:bg-gray-300 text-gray-800 px-6 py-2 rounded-md transition duration-300">
                        Cancelar
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Notificación de producto añadido -->
    <div id="notification" class="fixed top-4 right-4 z-50 hidden">
        <div class="bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg flex items-center space-x-3 transform transition-all duration-300 fade-in">
            <i class="fas fa-check-circle text-xl"></i>
            <span id="notificationText">Producto añadido al carrito</span>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    <script>
        // Función para mostrar notificación
        function mostrarNotificacion(mensaje, tipo = 'success') {
            const notification = document.getElementById('notification');
            const notificationText = document.getElementById('notificationText');
            
            notificationText.textContent = mensaje;
            
            // Cambiar color según el tipo
            if (tipo === 'error') {
                notification.firstElementChild.classList.remove('bg-green-500');
                notification.firstElementChild.classList.add('bg-red-500');
            } else {
                notification.firstElementChild.classList.remove('bg-red-500');
                notification.firstElementChild.classList.add('bg-green-500');
            }
            
            notification.classList.remove('hidden');
            notification.classList.add('fade-in');
            
            // Ocultar después de 3 segundos
            setTimeout(() => {
                notification.classList.remove('fade-in');
                notification.classList.add('fade-out');
                
                setTimeout(() => {
                    notification.classList.add('hidden');
                    notification.classList.remove('fade-out');
                }, 300);
            }, 3000);
        }
        
        // Funciones para el carrito
        function agregarAlCarrito(idProducto) {
            <?php if (!isset($_SESSION['user_id'])): ?>
                mostrarModalLogin();
            <?php else: ?>
                // Simular agregar al carrito (en producción esto sería una llamada AJAX)
                const productos = {
                    1: { id: 1, nombre: "Kit de Cadena", precio: 102000, imagen: "https://via.placeholder.com/300x200?text=Repuesto+Moto" },
                    2: { id: 2, nombre: "Pastillas de Freno", precio: 85000, imagen: "https://via.placeholder.com/300x200?text=Pastillas+Freno" }
                };
                
                const producto = productos[idProducto];
                
                // Verificar si el carrito existe en sessionStorage
                let carrito = JSON.parse(sessionStorage.getItem('carrito')) || {};
                
                // Agregar o actualizar producto en el carrito
                if (carrito[idProducto]) {
                    carrito[idProducto].cantidad += 1;
                } else {
                    carrito[idProducto] = {
                        ...producto,
                        cantidad: 1
                    };
                }
                
                // Guardar en sessionStorage
                sessionStorage.setItem('carrito', JSON.stringify(carrito));
                
                // Actualizar el contador del carrito
                const totalItems = Object.values(carrito).reduce((total, item) => total + item.cantidad, 0);
                actualizarContadorCarrito(totalItems);
                
                mostrarNotificacion('Producto añadido al carrito');
            <?php endif; ?>
        }
        
        function actualizarCantidad(idProducto, cambio) {
            // Obtener carrito de sessionStorage
            const carrito = JSON.parse(sessionStorage.getItem('carrito')) || {};
            
            if (carrito[idProducto]) {
                const nuevaCantidad = carrito[idProducto].cantidad + cambio;
                
                if (nuevaCantidad < 1) {
                    // Eliminar producto si la cantidad llega a 0
                    delete carrito[idProducto];
                } else {
                    // Actualizar cantidad
                    carrito[idProducto].cantidad = nuevaCantidad;
                }
                
                // Guardar cambios
                sessionStorage.setItem('carrito', JSON.stringify(carrito));
                
                // Actualizar el contador del carrito
                const totalItems = Object.values(carrito).reduce((total, item) => total + item.cantidad, 0);
                actualizarContadorCarrito(totalItems);
                
                // Recargar la página para ver los cambios
                location.reload();
            }
        }
        
        function eliminarProducto(idProducto) {
            // Obtener carrito de sessionStorage
            const carrito = JSON.parse(sessionStorage.getItem('carrito')) || {};
            
            if (carrito[idProducto]) {
                // Eliminar producto
                delete carrito[idProducto];
                
                // Guardar cambios
                sessionStorage.setItem('carrito', JSON.stringify(carrito));
                
                // Actualizar el contador del carrito
                const totalItems = Object.values(carrito).reduce((total, item) => total + item.cantidad, 0);
                actualizarContadorCarrito(totalItems);
                
                // Recargar la página para ver los cambios
                location.reload();
            }
        }
        
        function actualizarContadorCarrito(totalItems) {
            const cartIcon = document.querySelector('.fa-shopping-cart').parentElement;
            let badge = document.querySelector('.cart-badge');
            
            if (totalItems > 0) {
                if (!badge) {
                    badge = document.createElement('span');
                    badge.className = 'cart-badge';
                    cartIcon.appendChild(badge);
                }
                badge.textContent = totalItems;
            } else if (badge) {
                badge.remove();
            }
        }
        
        // Funciones para el modal
        function mostrarModalLogin() {
            const modal = document.getElementById('loginModal');
            modal.classList.remove('hidden');
        }
        
        function cerrarModal() {
            const modal = document.getElementById('loginModal');
            modal.classList.add('hidden');
        }
        
        // Cargar carrito al iniciar la página
        document.addEventListener('DOMContentLoaded', function() {
            const carrito = JSON.parse(sessionStorage.getItem('carrito')) || {};
            const totalItems = Object.values(carrito).reduce((total, item) => total + item.cantidad, 0);
            
            if (totalItems > 0) {
                actualizarContadorCarrito(totalItems);
            }
            
            // Mostrar mensajes del servidor si existen
            const urlParams = new URLSearchParams(window.location.search);
            const mensaje = urlParams.get('mensaje');
            const tipoMensaje = urlParams.get('tipoMensaje');
            
            if (mensaje) {
                mostrarNotificacion(mensaje, tipoMensaje);
            }
        });
    </script>
</body>
</html>