<?php
require_once __DIR__ . '/vendor/autoload.php';

function sendVerificationEmail($email, $verification_code) {
    $mail = new PHPMailer\PHPMailer\PHPMailer();
    
    try {
        // Configuración del servidor SMTP (ajusta estos valores)
        $mail->isSMTP();
        $mail->Host = 'smtp.example.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'ymejia0223@gmail.com';
        $mail->Password = 'ebcjrrfjbtmzpdja';
        $mail->SMTPSecure = PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;
        
        // Configuración del correo
        $mail->setFrom('no-reply@tudominio.com', 'Sistema de Recuperación');
        $mail->addAddress($email);
        $mail->Subject = 'Código de verificación para recuperación de contraseña';
        $mail->Body = "Tu código de verificación es: $verification_code\n\nEste código expirará en 30 segundos.";
        
        return $mail->send();
    } catch (Exception $e) {
        error_log("Error al enviar correo: " . $mail->ErrorInfo);
        return false;
    }
}
?>