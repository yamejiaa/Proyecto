<?php
session_start();
require_once '../includes/conexion.php';

// Verificar si el usuario está autenticado y es administrador
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 1) {
    header('Location: ../auth/login.php');
    exit;
}

// Obtener estadísticas de usuarios
$stats = [];
try {
    $stmt = $pdo->prepare("CALL sp_obtener_estadisticas_usuarios(@total, @activos, @bloqueados, @inactivos, @administradores, @usuarios_regulares)");
    $stmt->execute();
    
    // Obtener los resultados
    $result = $pdo->query("SELECT @total AS total, @activos AS activos, @bloqueados AS bloqueados, @inactivos AS inactivos, @administradores AS administradores, @usuarios_regulares AS usuarios_regulares")->fetch(PDO::FETCH_ASSOC);
    
    $stats = $result;
} catch (PDOException $e) {
    error_log("Error al obtener estadísticas: " . $e->getMessage());
}

// Obtener notificaciones NO LEÍDAS del usuario actual (solo las no leídas para el contador)
$notificaciones_no_leidas_count = 0;
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM notificaciones WHERE leida = 0 AND cedula_usuario = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $notificaciones_no_leidas_count = $result['count'];
} catch (PDOException $e) {
    error_log("Error al contar notificaciones no leídas: " . $e->getMessage());
}

// Obtener las últimas 5 notificaciones (todas para mostrarlas en el dropdown)
$notificaciones = [];
try {
    $stmt = $pdo->prepare("SELECT * FROM notificaciones WHERE cedula_usuario = ? ORDER BY leida ASC, fecha_creacion DESC LIMIT 5");
    $stmt->execute([$_SESSION['user_id']]);
    $notificaciones = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error al obtener notificaciones: " . $e->getMessage());
}

// Obtener información del usuario actual
$usuario_actual = [];
try {
    $stmt = $pdo->prepare("SELECT nombre, apellido, email FROM usuarios WHERE cedula = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $usuario_actual = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error al obtener información del usuario: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administración - Estadísticas</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
   <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body class="bg-gray-100 font-sans">
    <div class="flex h-screen overflow-hidden">
<!-- Sidebar -->
<aside id="sidebar" class="bg-[#2563eb] text-white fixed lg:relative h-full z-40 
    transition-all duration-300 ease-in-out 
    w-72 -translate-x-full lg:translate-x-0 lg:w-20 hover:w-72
    transform group">
    <div class="p-4 flex items-center justify-between border-b border-[#1e4fbf]">
        <div class="flex items-center space-x-2 cursor-pointer">
            <i class="fas fa-motorcycle text-xl text-white"></i>
            <span class="logo-text font-bold text-lg transition-all duration-200 
                hidden lg:group-hover:inline-block">MOTORIDES</span>
        </div>
        <button id="close-sidebar" class="text-white hover:text-blue-200 transition-all duration-200 
            mx-auto my-4 lg:mx-0 lg:my-0 hidden lg:block">
        </button>
    </div>

    <!-- Menú de navegación -->
    <nav class="p-4">
        <ul class="space-y-2">
            <li>
                <a href="index.php" class="sidebar-item flex items-center space-x-3 p-2 rounded-lg bg-[#1e4fbf] transition duration-200">
                    <i class="fas fa-chart-bar text-white"></i>
                    <span class="sidebar-text hidden lg:group-hover:inline-block">Estadísticas</span>
                </a>
            </li>
            <li>
                <a href="usuarios.php" class="sidebar-item flex items-center space-x-3 p-2 rounded-lg hover:bg-[#1e4fbf]">
                    <i class="fas fa-users text-white"></i>
                    <span class="sidebar-text hidden lg:group-hover:inline-block">Usuarios</span>
                </a>
            </li>
            <li>
                <a href="productos.php" class="sidebar-item flex items-center space-x-3 p-2 rounded-lg hover:bg-[#1e4fbf] transition duration-200">
                    <i class="fas fa-boxes text-white"></i>
                    <span class="sidebar-text hidden lg:group-hover:inline-block">Productos</span>
                </a>
            </li>
            <li>
                <a href="marcas.php" class="sidebar-item flex items-center space-x-3 p-2 rounded-lg hover:bg-[#1e4fbf] transition duration-200">
                    <i class="fas fa-tags text-white"></i>
                    <span class="sidebar-text hidden lg:group-hover:inline-block">Marcas</span>
                </a>
            </li>
            <li>
                <a href="ventas.php" class="sidebar-item flex items-center space-x-3 p-2 rounded-lg hover:bg-[#1e4fbf] transition duration-200">
                    <i class="fas fa-shopping-cart text-white"></i>
                    <span class="sidebar-text hidden lg:group-hover:inline-block">Ventas</span>
                </a>
            </li>
            <li>
                <a href="pedidos.php" class="sidebar-item flex items-center space-x-3 p-2 rounded-lg hover:bg-[#1e4fbf] transition duration-200">
                    <i class="fas fa-clipboard-list text-white"></i>
                    <span class="sidebar-text hidden lg:group-hover:inline-block">Pedidos</span>
                </a>
            </li>
        </ul>
    </nav>

    <!-- Perfil del usuario -->
    <div class="absolute bottom-0 left-0 right-0 p-4 border-t border-[#1e4fbf] bg-[#2563eb]">
        <div class="relative">
            <button id="profile-dropdown-btn" class="flex items-center space-x-3 w-full p-2 rounded-lg hover:bg-[#1e4fbf] transition duration-200">
                <div class="w-10 h-10 rounded-full bg-white flex items-center justify-center text-[#2563eb] font-bold">
                    <?php echo strtoupper(substr($usuario_actual['nombre'], 0, 1)); ?>
                </div>
                <div class="text-left sidebar-text hidden lg:group-hover:block">
                    <p class="font-medium truncate"><?php echo htmlspecialchars($usuario_actual['nombre']); ?></p>
                    <p class="text-xs text-blue-200">Administrador</p>
                </div>
            </button>

            <!-- Dropdown del perfil -->
            <div id="profile-dropdown" class="hidden absolute bottom-full mb-2 left-0 right-0 bg-white rounded-lg shadow-lg z-50 py-1 text-gray-800 
                transform transition-all duration-200 ease-in-out origin-bottom opacity-0 scale-95">
                <a href="#" class="block px-4 py-2 hover:bg-blue-50 transition duration-150">
                    <i class="fas fa-user-circle mr-2 text-[#2563eb]"></i> Mi perfil
                </a>
                <a href="#" class="block px-4 py-2 hover:bg-blue-50 transition duration-150">
                    <i class="fas fa-cog mr-2 text-[#2563eb]"></i> Configuración
                </a>
                <a href="../includes/logout.php" class="block px-4 py-2 hover:bg-blue-50 text-red-500 transition duration-150">
                    <i class="fas fa-sign-out-alt mr-2"></i> Cerrar sesión
                </a>
            </div>
        </div>
    </div>
</aside>

<!-- Overlay para móviles -->
<div id="overlay" class="fixed inset-0 bg-black bg-opacity-50 z-30 
    hidden transition-opacity duration-300 ease-in-out"></div>

        <!-- Contenido principal -->
        <div class="flex-1 flex flex-col overflow-hidden">
            <!-- Header -->
            <header class="bg-white shadow-sm z-20">
                <div class="flex items-center justify-between px-6 py-4">
                    <div class="flex items-center">
                        <button id="mobile-menu-button" class="text-gray-500 hover:text-gray-600 lg:hidden mr-4">
                            <i class="fas fa-bars"></i>
                        </button>
                        <h1 class="text-xl font-semibold text-gray-800">Estadísticas</h1>
                    </div>
                    
                    <div class="flex items-center space-x-4">
                        <!-- Notificaciones -->
<div class="relative">
    <button id="notification-btn" class="notification-btn p-2 rounded-full hover:bg-gray-100 transition-colors duration-200 relative">
        <i class="fas fa-bell text-xl text-gray-600"></i>
        <?php if ($notificaciones_no_leidas_count > 0): ?>
            <span class="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center animate-pulse">
                <?php echo $notificaciones_no_leidas_count; ?>
            </span>
        <?php endif; ?>
    </button>
    
    <!-- Dropdown de notificaciones -->
    <div id="notification-dropdown" class="hidden absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg z-50 border border-gray-200 transform transition-all duration-200 ease-in-out origin-top opacity-0 scale-95">
        <div class="px-4 py-3 border-b border-gray-200 flex justify-between items-center bg-gray-50 rounded-t-lg">
            <h3 class="font-medium text-gray-800">Notificaciones</h3>
            <div class="flex space-x-2">
                <button id="mark-all-read" class="text-xs <?php echo count($notificaciones) > 0 ? 'text-blue-500 hover:text-blue-700' : 'text-gray-400 cursor-not-allowed'; ?>" <?php echo count($notificaciones) == 0 ? 'disabled' : ''; ?>>Marcar todas como leídas</button>
                <button id="delete-all-notifications" class="text-xs <?php echo count($notificaciones) > 0 ? 'text-red-500 hover:text-red-700' : 'text-gray-400 cursor-not-allowed'; ?>" <?php echo count($notificaciones) == 0 ? 'disabled' : ''; ?>>Eliminar todas</button>
            </div>
        </div>
        <div class="notifications-container max-h-96 overflow-y-auto">
            <?php if (count($notificaciones) > 0): ?>
                <?php foreach ($notificaciones as $notificacion): ?>
                    <div class="notification-item px-4 py-3 border-b border-gray-200 hover:bg-gray-50 flex justify-between items-start transition-colors duration-150 <?php echo $notificacion['leida'] ? 'bg-gray-200' : 'bg-white'; ?>">
                        <div class="flex-1">
                            <p class="text-sm font-medium text-gray-800"><?php echo htmlspecialchars($notificacion['titulo']); ?></p>
                            <p class="text-xs text-gray-500 mt-1"><?php echo htmlspecialchars($notificacion['mensaje']); ?></p>
                            <p class="text-xs text-gray-400 mt-2">
                                <?php echo date('d M H:i', strtotime($notificacion['fecha_creacion'])); ?>
                            </p>
                        </div>
                        <button class="delete-notification text-gray-400 hover:text-red-500 ml-2 transition-colors duration-150" 
                            data-id="<?php echo $notificacion['id']; ?>"
                            onclick="deleteNotification(event, <?php echo $notificacion['id']; ?>)">
                            <i class="fas fa-trash-alt text-xs"></i>
                        </button>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="px-4 py-6 text-center">
                    <i class="fas fa-bell-slash text-gray-300 text-2xl mb-2"></i>
                    <p class="text-sm text-gray-500">No hay notificaciones nuevas</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
                    </div>
                </div>
            </header>

<main class="flex-1 overflow-y-auto p-6 bg-gray-50">
                <!-- Estadísticas -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
                    <!-- Total Usuarios -->
                    <div class="bg-white rounded-lg shadow p-6">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-gray-500">Total Usuarios</p>
                                <h3 class="text-2xl font-bold text-gray-800"><?php echo $stats['total'] ?? 0; ?></h3>
                            </div>
                            <div class="bg-blue-100 p-3 rounded-full">
                                <i class="fas fa-users text-blue-500 text-xl"></i>
                            </div>
                        </div>
                        <div class="mt-4">
                            <div class="flex justify-between text-sm text-gray-500">
                                <span>Activos: <?php echo $stats['activos'] ?? 0; ?></span>
                                <span>Inactivos: <?php echo $stats['inactivos'] ?? 0; ?></span>
                                <span>Bloqueados: <?php echo $stats['bloqueados'] ?? 0; ?></span>
                            </div>
                        </div>
                    </div>

                    <!-- Administradores -->
                    <div class="bg-white rounded-lg shadow p-6">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-gray-500">Administradores</p>
                                <h3 class="text-2xl font-bold text-gray-800"><?php echo $stats['administradores'] ?? 0; ?></h3>
                            </div>
                            <div class="bg-purple-100 p-3 rounded-full">
                                <i class="fas fa-user-shield text-purple-500 text-xl"></i>
                            </div>
                        </div>
                        <div class="mt-4">
                            <div class="h-2 bg-gray-200 rounded-full">
                                <div class="h-2 bg-purple-500 rounded-full" style="width: <?php echo $stats['total'] > 0 ? ($stats['administradores'] / $stats['total'] * 100) : 0; ?>%"></div>
                            </div>
                            <p class="text-xs text-gray-500 mt-2"><?php echo $stats['total'] > 0 ? round($stats['administradores'] / $stats['total'] * 100, 2) : 0; ?>% del total</p>
                        </div>
                    </div>

                    <!-- Usuarios Regulares -->
                    <div class="bg-white rounded-lg shadow p-6">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-gray-500">Usuarios Regulares</p>
                                <h3 class="text-2xl font-bold text-gray-800"><?php echo $stats['usuarios_regulares'] ?? 0; ?></h3>
                            </div>
                            <div class="bg-green-100 p-3 rounded-full">
                                <i class="fas fa-user text-green-500 text-xl"></i>
                            </div>
                        </div>
                        <div class="mt-4">
                            <div class="h-2 bg-gray-200 rounded-full">
                                <div class="h-2 bg-green-500 rounded-full" style="width: <?php echo $stats['total'] > 0 ? ($stats['usuarios_regulares'] / $stats['total'] * 100) : 0; ?>%"></div>
                            </div>
                            <p class="text-xs text-gray-500 mt-2"><?php echo $stats['total'] > 0 ? round($stats['usuarios_regulares'] / $stats['total'] * 100, 2) : 0; ?>% del total</p>
                        </div>
                    </div>
                </div>

                <!-- Gráficos o más estadísticas -->
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <!-- Últimos registros -->
                    <div class="bg-white rounded-lg shadow p-6">
                        <h3 class="text-lg font-semibold text-gray-800 mb-4">Últimos registros</h3>
                        <div class="overflow-x-auto">
                            <table class="min-w-full divide-y divide-gray-200">
                                <thead class="bg-gray-50">
                                    <tr>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nombre</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fecha</th>
                                    </tr>
                                </thead>
                                <tbody class="bg-white divide-y divide-gray-200">
                                    <?php
                                    try {
                                        $stmt = $pdo->query("SELECT nombre, apellido, email, fecha_registro FROM usuarios ORDER BY fecha_registro DESC LIMIT 5");
                                        $ultimos_registros = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                        
                                        foreach ($ultimos_registros as $registro):
                                    ?>
                                    <tr>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?php echo htmlspecialchars($registro['nombre'] . ' ' . htmlspecialchars($registro['apellido'])); ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo htmlspecialchars($registro['email']); ?></td>
                                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo date('d M Y', strtotime($registro['fecha_registro'])); ?></td>
                                    </tr>
                                    <?php
                                        endforeach;
                                    } catch (PDOException $e) {
                                        error_log("Error al obtener últimos registros: " . $e->getMessage());
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- Actividad reciente -->
                    <div class="bg-white rounded-lg shadow p-6">
                        <h3 class="text-lg font-semibold text-gray-800 mb-4">Actividad reciente</h3>
                        <div class="space-y-4">
                            <?php
                            try {
                                $stmt = $pdo->query("SELECT l.*, u.nombre, u.apellido FROM logs_autenticacion l JOIN usuarios u ON l.cedula_usuario = u.cedula ORDER BY l.fecha_evento DESC LIMIT 5");
                                $actividad = $stmt->fetchAll(PDO::FETCH_ASSOC);
                                
                                foreach ($actividad as $evento):
                            ?>
                            <div class="flex items-start">
                                <div class="flex-shrink-0 h-10 w-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-500 mr-3">
                                    <i class="fas 
                                        <?php 
                                        switch($evento['tipo_evento']) {
                                            case 'login': echo 'fa-sign-in-alt'; break;
                                            case 'logout': echo 'fa-sign-out-alt'; break;
                                            case 'registro': echo 'fa-user-plus'; break;
                                            case 'bloqueo': echo 'fa-lock'; break;
                                            default: echo 'fa-info-circle';
                                        }
                                        ?>
                                    "></i>
                                </div>
                                <div>
                                    <p class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($evento['nombre'] . ' ' . htmlspecialchars($evento['apellido'])); ?></p>
                                    <p class="text-sm text-gray-500"><?php echo htmlspecialchars($evento['detalles']); ?></p>
                                    <p class="text-xs text-gray-400 mt-1"><?php echo date('d M H:i', strtotime($evento['fecha_evento'])); ?></p>
                                </div>
                            </div>
                            <?php
                                endforeach;
                            } catch (PDOException $e) {
                                error_log("Error al obtener actividad reciente: " . $e->getMessage());
                            }
                            ?>
                        </div>
                    </div>
                </div>
            </main>
            <!-- Footer -->
            <footer class="bg-white border-t border-gray-200 py-4 px-6">
                <div class="flex flex-col md:flex-row justify-between items-center">
                    <p class="text-sm text-gray-500 text-center">© <?php echo date('Y'); ?> AdminPanel. Todos los derechos reservados.</p>
                    <div class="flex space-x-4 mt-2 md:mt-0">
                        <a href="#" class="text-sm text-gray-500 hover:text-gray-700">Términos</a>
                        <a href="#" class="text-sm text-gray-500 hover:text-gray-700">Privacidad</a>
                        <a href="#" class="text-sm text-gray-500 hover:text-gray-700">Contacto</a>
                    </div>
                </div>
            </footer>
        </div>
    </div>

    <!-- JavaScript -->
    <script src="../assets/js/admin.js"></script>
</body>
</html>