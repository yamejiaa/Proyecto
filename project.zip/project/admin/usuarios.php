<?php
session_start();
require_once '../includes/conexion.php';

// Verificar si el usuario está autenticado y es administrador
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 1) {
    header('Location: ../auth/login.php');
    exit;
}

// Obtener estadísticas de usuarios
$stats = [];
try {
    $stmt = $pdo->prepare("CALL sp_obtener_estadisticas_usuarios(@total, @activos, @bloqueados, @inactivos, @administradores, @usuarios_regulares)");
    $stmt->execute();
    
    // Obtener los resultados
    $result = $pdo->query("SELECT @total AS total, @activos AS activos, @bloqueados AS bloqueados, @inactivos AS inactivos, @administradores AS administradores, @usuarios_regulares AS usuarios_regulares")->fetch(PDO::FETCH_ASSOC);
    
    $stats = $result;
} catch (PDOException $e) {
    error_log("Error al obtener estadísticas: " . $e->getMessage());
}

// Obtener notificaciones NO LEÍDAS del usuario actual (solo las no leídas para el contador)
$notificaciones_no_leidas_count = 0;
try {
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM notificaciones WHERE leida = 0 AND cedula_usuario = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $notificaciones_no_leidas_count = $result['count'];
} catch (PDOException $e) {
    error_log("Error al contar notificaciones no leídas: " . $e->getMessage());
}

// Obtener las últimas 5 notificaciones (todas para mostrarlas en el dropdown)
$notificaciones = [];
try {
    $stmt = $pdo->prepare("SELECT * FROM notificaciones WHERE cedula_usuario = ? ORDER BY leida ASC, fecha_creacion DESC LIMIT 5");
    $stmt->execute([$_SESSION['user_id']]);
    $notificaciones = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error al obtener notificaciones: " . $e->getMessage());
}

// Obtener información del usuario actual
$usuario_actual = [];
try {
    $stmt = $pdo->prepare("SELECT nombre, apellido, email FROM usuarios WHERE cedula = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $usuario_actual = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Error al obtener información del usuario: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Panel de Administración - Usuarios</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body class="bg-gray-100 font-sans">
    <div class="flex h-screen overflow-hidden">
        <!-- Sidebar -->
<!-- Sidebar -->
<aside id="sidebar" class="bg-[#2563eb] text-white fixed lg:relative h-full z-40 
    transition-all duration-300 ease-in-out 
    w-72 -translate-x-full lg:translate-x-0 lg:w-20 hover:w-72
    transform group">
    <div class="p-4 flex items-center justify-between border-b border-[#1e4fbf]">
        <div class="flex items-center space-x-2 cursor-pointer">
            <i class="fas fa-motorcycle text-xl text-white"></i>
            <span class="logo-text font-bold text-lg transition-all duration-200 
                hidden lg:group-hover:inline-block">MOTORIDES</span>
        </div>
        <button id="close-sidebar" class="text-white hover:text-blue-200 transition-all duration-200 
            mx-auto my-4 lg:mx-0 lg:my-0 hidden lg:block">
        </button>
    </div>

    <!-- Menú de navegación -->
    <nav class="p-4">
        <ul class="space-y-2">
            <li>
                <a href="index.php" class="sidebar-item flex items-center space-x-3 p-2 rounded-lg hover:bg-[#1e4fbf] transition duration-200">
                    <i class="fas fa-chart-bar text-white"></i>
                    <span class="sidebar-text hidden lg:group-hover:inline-block">Estadísticas</span>
                </a>
            </li>
            <li>
                <a href="usuarios.php" class="sidebar-item flex items-center space-x-3 p-2 rounded-lg bg-[#1e4fbf]">
                    <i class="fas fa-users text-white"></i>
                    <span class="sidebar-text hidden lg:group-hover:inline-block">Usuarios</span>
                </a>
            </li>
            <li>
                <a href="productos.php" class="sidebar-item flex items-center space-x-3 p-2 rounded-lg hover:bg-[#1e4fbf] transition duration-200">
                    <i class="fas fa-boxes text-white"></i>
                    <span class="sidebar-text hidden lg:group-hover:inline-block">Productos</span>
                </a>
            </li>
            <li>
                <a href="marcas.php" class="sidebar-item flex items-center space-x-3 p-2 rounded-lg hover:bg-[#1e4fbf] transition duration-200">
                    <i class="fas fa-tags text-white"></i>
                    <span class="sidebar-text hidden lg:group-hover:inline-block">Marcas</span>
                </a>
            </li>
            <li>
                <a href="ventas.php" class="sidebar-item flex items-center space-x-3 p-2 rounded-lg hover:bg-[#1e4fbf] transition duration-200">
                    <i class="fas fa-shopping-cart text-white"></i>
                    <span class="sidebar-text hidden lg:group-hover:inline-block">Ventas</span>
                </a>
            </li>
            <li>
                <a href="pedidos.php" class="sidebar-item flex items-center space-x-3 p-2 rounded-lg hover:bg-[#1e4fbf] transition duration-200">
                    <i class="fas fa-clipboard-list text-white"></i>
                    <span class="sidebar-text hidden lg:group-hover:inline-block">Pedidos</span>
                </a>
            </li>
        </ul>
    </nav>

    <!-- Perfil del usuario -->
    <div class="absolute bottom-0 left-0 right-0 p-4 border-t border-[#1e4fbf] bg-[#2563eb]">
        <div class="relative">
            <button id="profile-dropdown-btn" class="flex items-center space-x-3 w-full p-2 rounded-lg hover:bg-[#1e4fbf] transition duration-200">
                <div class="w-10 h-10 rounded-full bg-white flex items-center justify-center text-[#2563eb] font-bold">
                    <?php echo strtoupper(substr($usuario_actual['nombre'], 0, 1)); ?>
                </div>
                <div class="text-left sidebar-text hidden lg:group-hover:block">
                    <p class="font-medium truncate"><?php echo htmlspecialchars($usuario_actual['nombre']); ?></p>
                    <p class="text-xs text-blue-200">Administrador</p>
                </div>
            </button>

            <!-- Dropdown del perfil -->
            <div id="profile-dropdown" class="hidden absolute bottom-full mb-2 left-0 right-0 bg-white rounded-lg shadow-lg z-50 py-1 text-gray-800 
                transform transition-all duration-200 ease-in-out origin-bottom opacity-0 scale-95">
                <a href="#" class="block px-4 py-2 hover:bg-blue-50 transition duration-150">
                    <i class="fas fa-user-circle mr-2 text-[#2563eb]"></i> Mi perfil
                </a>
                <a href="#" class="block px-4 py-2 hover:bg-blue-50 transition duration-150">
                    <i class="fas fa-cog mr-2 text-[#2563eb]"></i> Configuración
                </a>
                <a href="../includes/logout.php" class="block px-4 py-2 hover:bg-blue-50 text-red-500 transition duration-150">
                    <i class="fas fa-sign-out-alt mr-2"></i> Cerrar sesión
                </a>
            </div>
        </div>
    </div>
</aside>

<!-- Overlay para móviles -->
<div id="overlay" class="fixed inset-0 bg-black bg-opacity-50 z-30 
    hidden transition-opacity duration-300 ease-in-out"></div>

        <!-- Contenido principal -->
        <div class="flex-1 flex flex-col overflow-hidden">
            <!-- Header -->
            <header class="bg-white shadow-lg z-20">
                <div class="flex items-center justify-between px-6 py-4">
                    <div class="flex items-center">
                        <button id="mobile-menu-button" class="text-gray-500 hover:text-gray-600 lg:hidden mr-4">
                            <i class="fas fa-bars"></i>
                        </button>
                        <h1 class="text-xl font-semibold text-gray-800">Usuarios</h1>
                    </div>
                    
                    <div class="flex items-center space-x-4">
                        <!-- Notificaciones -->
<div class="relative">
    <button id="notification-btn" class="notification-btn p-2 rounded-full hover:bg-gray-100 transition-colors duration-200 relative">
        <i class="fas fa-bell text-xl text-gray-600"></i>
        <?php if ($notificaciones_no_leidas_count > 0): ?>
            <span class="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center animate-pulse">
                <?php echo $notificaciones_no_leidas_count; ?>
            </span>
        <?php endif; ?>
    </button>
    
    <!-- Dropdown de notificaciones -->
    <div id="notification-dropdown" class="hidden absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg z-50 border border-gray-200 transform transition-all duration-200 ease-in-out origin-top opacity-0 scale-95">
        <div class="px-4 py-3 border-b border-gray-200 flex justify-between items-center bg-gray-50 rounded-t-lg">
            <h3 class="font-medium text-gray-800">Notificaciones</h3>
            <div class="flex space-x-2">
                <button id="mark-all-read" class="text-xs <?php echo count($notificaciones) > 0 ? 'text-blue-500 hover:text-blue-700' : 'text-gray-400 cursor-not-allowed'; ?>" <?php echo count($notificaciones) == 0 ? 'disabled' : ''; ?>>Marcar todas como leídas</button>
                <button id="delete-all-notifications" class="text-xs <?php echo count($notificaciones) > 0 ? 'text-red-500 hover:text-red-700' : 'text-gray-400 cursor-not-allowed'; ?>" <?php echo count($notificaciones) == 0 ? 'disabled' : ''; ?>>Eliminar todas</button>
            </div>
        </div>
        <div class="notifications-container max-h-96 overflow-y-auto">
            <?php if (count($notificaciones) > 0): ?>
                <?php foreach ($notificaciones as $notificacion): ?>
                    <div class="notification-item px-4 py-3 border-b border-gray-200 hover:bg-gray-50 flex justify-between items-start transition-colors duration-150 <?php echo $notificacion['leida'] ? 'bg-gray-200' : 'bg-white'; ?>">
                        <div class="flex-1">
                            <p class="text-sm font-medium text-gray-800"><?php echo htmlspecialchars($notificacion['titulo']); ?></p>
                            <p class="text-xs text-gray-500 mt-1"><?php echo htmlspecialchars($notificacion['mensaje']); ?></p>
                            <p class="text-xs text-gray-400 mt-2">
                                <?php echo date('d M H:i', strtotime($notificacion['fecha_creacion'])); ?>
                            </p>
                        </div>
                        <button class="delete-notification text-gray-400 hover:text-red-500 ml-2 transition-colors duration-150" 
                            data-id="<?php echo $notificacion['id']; ?>"
                            onclick="deleteNotification(event, <?php echo $notificacion['id']; ?>)">
                            <i class="fas fa-trash-alt text-xs"></i>
                        </button>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="px-4 py-6 text-center">
                    <i class="fas fa-bell-slash text-gray-300 text-2xl mb-2"></i>
                    <p class="text-sm text-gray-500">No hay notificaciones nuevas</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
                    </div>
                </div>
            </header>

            <!-- Contenido -->
            <main class="flex-1 overflow-y-auto p-6 bg-gray-50">
    <!-- Filtros y botones -->
    <div class="mb-6">
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center space-y-4 md:space-y-0">
            <h2 class="text-xl font-semibold text-gray-800">Gestión de Usuarios</h2>
            <div class="flex space-x-3">
                <button id="add-user-btn" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
    <i class="fas fa-plus mr-2"></i> Nuevo Usuario
</button>
            </div>
        </div>
        
        <!-- Filtros -->
        <div class="mt-6 bg-white p-4 rounded-lg shadow-lg">
            <form id="filter-form" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                    <label for="search" class="block text-sm font-medium text-gray-700 mb-1">Buscar</label>
                    <input type="text" id="search" name="search" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                
                <div>
                    <label for="role" class="block text-sm font-medium text-gray-700 mb-1">Rol</label>
                    <select id="role" name="role" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="">Todos</option>
                        <option value="1">Administrador</option>
                        <option value="2">Usuario</option>
                    </select>
                </div>
                
                <div>
                    <label for="status" class="block text-sm font-medium text-gray-700 mb-1">Estado</label>
                    <select id="status" name="status" class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                        <option value="">Todos</option>
                        <option value="activo">Activo</option>
                        <option value="inactivo">Inactivo</option>
                        <option value="bloqueado">Bloqueado</option>
                    </select>
                </div>
                
                <div class="flex items-end">
                    <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition w-full">
                        <i class="fas fa-filter mr-2"></i> Filtrar
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Tabla de usuarios -->
    <div class="bg-white rounded-lg shadow-lg overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50 ">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nombre</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cédula</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Rol</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estado</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Último Login</th>
                        <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200" id="users-table-body">
                    <?php
                    try {
                        // Obtener usuarios con paginación
                        $pagina = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
                        $por_pagina = 10;
                        
                        // Contar total de usuarios
                        $stmt = $pdo->prepare("CALL sp_contar_usuarios(?, ?, ?, @total)");
                        $stmt->execute([
                            isset($_GET['search']) ? $_GET['search'] : null,
                            isset($_GET['status']) ? $_GET['status'] : null,
                            isset($_GET['role']) ? $_GET['role'] : null
                        ]);
                        $total_result = $pdo->query("SELECT @total AS total")->fetch(PDO::FETCH_ASSOC);
                        $total_usuarios = $total_result['total'];
                        $total_paginas = ceil($total_usuarios / $por_pagina);
                        
                        // Obtener usuarios
                        $stmt = $pdo->prepare("CALL sp_buscar_usuarios(?, ?, ?, ?, ?)");
                        $stmt->execute([
                            isset($_GET['search']) ? $_GET['search'] : null,
                            isset($_GET['status']) ? $_GET['status'] : null,
                            isset($_GET['role']) ? $_GET['role'] : null,
                            $pagina,
                            $por_pagina
                        ]);
                        $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
                        
                        foreach ($usuarios as $usuario):
                            $estado_clases = [
                                'activo' => 'bg-green-100 text-green-800',
                                'inactivo' => 'bg-yellow-100 text-yellow-800',
                                'bloqueado' => 'bg-red-100 text-red-800'
                            ];
                            
                            $rol_clases = [
                                'admin' => 'bg-purple-100 text-purple-800',
                                'usuario' => 'bg-blue-100 text-blue-800'
                            ];
                    ?>
                    <tr>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="">
                                <div class="">
                                    <div class="text-sm font-medium text-gray-900"><?php echo htmlspecialchars($usuario['nombre'] . ' ' . htmlspecialchars($usuario['apellido'])); ?></div>
                                </div>
                            </div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo htmlspecialchars($usuario['cedula']); ?></td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo htmlspecialchars($usuario['email']); ?></td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo $rol_clases[$usuario['id_rol'] == 1 ? 'admin' : 'usuario'] ?? 'bg-gray-100 text-gray-800'; ?>">
    <?php echo $usuario['id_rol'] == 1 ? 'Administrador' : 'Usuario'; ?>
</span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full <?php echo $estado_clases[$usuario['estado']] ?? 'bg-gray-100 text-gray-800'; ?>">
                                <?php 
                                echo ucfirst($usuario['estado']);
                                if ($usuario['estado'] === 'bloqueado' && $usuario['intentos_fallidos'] >= 5) {
                                    echo ' (5+ intentos)';
                                }
                                ?>
                            </span>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            <?php echo $usuario['ultimo_login'] ? date('d M Y H:i', strtotime($usuario['ultimo_login'])) : 'Nunca'; ?>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                            <div class="flex justify-end space-x-2">
                                <button class="edit-user text-blue-600 hover:text-blue-900" data-id="<?php echo $usuario['cedula']; ?>">
                                    <i class="fas fa-edit"></i>
                                </button>
                                
                                <?php if ($usuario['estado'] === 'bloqueado'): ?>
                                    <button class="unblock-user text-green-600 hover:text-green-900" data-id="<?php echo $usuario['cedula']; ?>">
                                        <i class="fas fa-unlock"></i>
                                    </button>
                                <?php else: ?>
                                    <button class="block-user text-yellow-600 hover:text-yellow-900" data-id="<?php echo $usuario['cedula']; ?>">
                                        <i class="fas fa-lock"></i>
                                    </button>
                                <?php endif; ?>
                                
                                <button class="delete-user text-red-600 hover:text-red-900" data-id="<?php echo $usuario['cedula']; ?>">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php
                        endforeach;
                    } catch (PDOException $e) {
                        error_log("Error al obtener usuarios: " . $e->getMessage());
                        echo '<tr><td colspan="7" class="px-6 py-4 text-center text-red-500">Error al cargar los usuarios</td></tr>';
                    }
                    ?>
                </tbody>
            </table>
        </div>
        
        <!-- Paginación -->
        <div class="bg-white px-4 py-3 flex items-center justify-between border-t border-gray-200 sm:px-6">
            <div class="flex-1 flex justify-between sm:hidden">
                <a href="usuarios.php?pagina=<?php echo max(1, $pagina - 1); ?>" class="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                    Anterior
                </a>
                <a href="usuarios.php?pagina=<?php echo min($total_paginas, $pagina + 1); ?>" class="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                    Siguiente
                </a>
            </div>
            <div class="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
                <div>
                    <p class="text-sm text-gray-700">
                        Mostrando <span class="font-medium"><?php echo (($pagina - 1) * $por_pagina) + 1; ?></span> a <span class="font-medium"><?php echo min($pagina * $por_pagina, $total_usuarios); ?></span> de <span class="font-medium"><?php echo $total_usuarios; ?></span> usuarios
                    </p>
                </div>
                <div>
                    <nav class="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                        <a href="usuarios.php?pagina=<?php echo max(1, $pagina - 1); ?>" class="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                            <span class="sr-only">Anterior</span>
                            <i class="fas fa-chevron-left"></i>
                        </a>
                        
                        <?php for ($i = 1; $i <= $total_paginas; $i++): ?>
                            <a href="usuarios.php?pagina=<?php echo $i; ?>" class="<?php echo $i == $pagina ? 'bg-blue-50 border-blue-500 text-blue-600' : 'bg-white border-gray-300 text-gray-500 hover:bg-gray-50'; ?> relative inline-flex items-center px-4 py-2 border text-sm font-medium">
                                <?php echo $i; ?>
                            </a>
                        <?php endfor; ?>
                        
                        <a href="usuarios.php?pagina=<?php echo min($total_paginas, $pagina + 1); ?>" class="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50">
                            <span class="sr-only">Siguiente</span>
                            <i class="fas fa-chevron-right"></i>
                        </a>
                    </nav>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Modal para acciones -->
<div id="action-modal" class="hidden fixed inset-0 overflow-y-auto z-50">
    <div class="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div class="fixed inset-0 transition-opacity" aria-hidden="true">
            <div class="absolute inset-0 bg-gray-500 opacity-75"></div>
        </div>
        
        <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
        
        <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
            <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <div class="sm:flex sm:items-start">
                    <div class="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-blue-100 sm:mx-0 sm:h-10 sm:w-10">
                        <i class="fas fa-info-circle text-blue-600"></i>
                    </div>
                    <div class="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                        <h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">Confirmar acción</h3>
                        <div class="mt-2">
                            <p class="text-sm text-gray-500" id="modal-message">¿Estás seguro de que deseas realizar esta acción?</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                <button type="button" id="confirm-action" class="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm">
                    Confirmar
                </button>
                <button type="button" id="cancel-action" class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm">
                    Cancelar
                </button>
            </div>
        </div>
    </div>
</div>
    
    <!-- Modal de éxito/error -->
    <div id="message-modal" class="fixed top-4 right-4 z-50 hidden">
        <div class="<?php echo $tipoMensaje === 'success' ? 'bg-green-500' : 'bg-red-500'; ?> text-white px-6 py-4 rounded-lg shadow-lg flex items-center">
            <i class="fas <?php echo $tipoMensaje === 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?> mr-2"></i>
            <span id="message-text"><?php echo !empty($mensaje) ? $mensaje : ''; ?></span>
            <button onclick="document.getElementById('message-modal').classList.add('hidden')" class="ml-4">
                <i class="fas fa-times"></i>
            </button>
        </div>
    </div>
</main>
            <!-- Footer -->
            <footer class="bg-white border-t border-gray-200 py-4 px-6">
                <div class="flex flex-col md:flex-row justify-between items-center">
                    <p class="text-sm text-gray-500">© <?php echo date('Y'); ?> AdminPanel. Todos los derechos reservados.</p>
                    <div class="flex space-x-4 mt-2 md:mt-0">
                        <a href="#" class="text-sm text-gray-500 hover:text-gray-700">Términos</a>
                        <a href="#" class="text-sm text-gray-500 hover:text-gray-700">Privacidad</a>
                        <a href="#" class="text-sm text-gray-500 hover:text-gray-700">Contacto</a>
                    </div>
                </div>
            </footer>
        </div>
    </div>

    <!-- Modal para agregar usuario -->
<!-- Modal para agregar usuario -->
<div id="add-user-modal" class="fixed inset-0 z-50 hidden overflow-y-auto">
    <!-- Fondo oscuro con transición -->
    <div id="modal-backdrop" class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity duration-300 ease-in-out opacity-0"></div>
    
    <!-- Contenedor del modal con transición -->
    <div class="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <!-- Espacio para centrar verticalmente -->
        <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
        
        <!-- Contenido del modal con animación -->
        <div id="modal-content" class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95">
            <!-- Cabecera del modal -->
            <div class="bg-gradient-to-r from-blue-600 to-purple-500 p-6 text-white">
                <h1 class="text-2xl font-bold flex items-center gap-2 justify-center">
                <i class="fas fa-user-plus"></i> Agregar nuevo usuario
                <button id="close-add-user-modal" class="absolute top-4 right-4 text-white hover:text-gray-200 transition duration-200">
                    <i class="fas fa-times"></i>
                </button>
                <script>const closeBtn = document.getElementById('close-add-user-modal');
if (closeBtn) {
    closeBtn.addEventListener('click', function () {
        const modal = document.getElementById('add-user-modal');
        const backdrop = document.getElementById('modal-backdrop');
        const content = document.getElementById('modal-content');

        backdrop.classList.remove('opacity-100');
        backdrop.classList.add('opacity-0');
        content.classList.remove('opacity-100', 'translate-y-0', 'sm:scale-100');
        content.classList.add('opacity-0', 'translate-y-4', 'sm:scale-95');

        setTimeout(() => {
            modal.classList.add('hidden');
            document.getElementById('add-user-form').reset();
        }, 300);
    });
}
</script>
            </h1>
            </div>
            
            <!-- Formulario (mantén tu formulario actual aquí) -->
            <form id="add-user-form" class="p-6 space-y-4">
                <div class="grid grid-cols-1 gap-4">
                    <div>
                        <label for="add-cedula" class="block text-sm font-medium text-gray-700 mb-1">Cédula</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="fas fa-id-card text-gray-400"></i>
                            </div>
                            <input type="text" id="add-cedula" name="cedula" required
                                class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-300"
                                placeholder="1234567890" pattern="[0-9]{6,20}">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label for="add-nombre" class="block text-sm font-medium text-gray-700 mb-1">Nombre</label>
                            <div class="relative">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i class="fas fa-user text-gray-400"></i>
                                </div>
                                <input type="text" id="add-nombre" name="nombre" required
                                    class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-300"
                                    placeholder="Nombre">
                            </div>
                        </div>
                        
                        <div>
                            <label for="add-apellido" class="block text-sm font-medium text-gray-700 mb-1">Apellido</label>
                            <div class="relative">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i class="fas fa-user text-gray-400"></i>
                                </div>
                                <input type="text" id="add-apellido" name="apellido" required
                                    class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-300"
                                    placeholder="Apellido">
                            </div>
                        </div>
                    </div>
                    
                    <div>
                        <label for="add-email" class="block text-sm font-medium text-gray-700 mb-1">Correo Electrónico</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="fas fa-envelope text-gray-400"></i>
                            </div>
                            <input type="email" id="add-email" name="email" required
                                class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-300"
                                placeholder="tu@email.com">
                        </div>
                    </div>
                    
                    <div>
                        <label for="add-rol" class="block text-sm font-medium text-gray-700 mb-1">Rol</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="fas fa-user text-gray-400"></i>
                            </div>
                        <select id="add-rol" name="id_rol" required
                            class="block w-full pl-10 pr-10 bg-white px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-300">
                            <option value="" disabled selected>Seleccione un rol</option>
                            <option value="1">Administrador</option>
                            <option value="2">Usuario</option>
                        </select>
                        </div>
                    </div>
                    
                    <div>
                        <label for="add-password" class="block text-sm font-medium text-gray-700 mb-1">Contraseña</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="fas fa-lock text-gray-400"></i>
                            </div>
                            <input type="password" id="add-password" name="password" required
                                class="block w-full pl-10 pr-10 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-300"
                                placeholder="••••••••" minlength="8" pattern="^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$">
                            <button type="button" id="toggle-add-password" class="absolute inset-y-0 right-0 pr-3 flex items-center">
                                <i class="fas fa-eye text-gray-400 hover:text-gray-600 cursor-pointer"></i>
                            </button>
                        </div>
                        <p class="mt-1 text-xs text-gray-500">Mínimo 8 caracteres con números y letras</p>
                    </div>
                    
                    <div>
                        <label for="add-confirm-password" class="block text-sm font-medium text-gray-700 mb-1">Confirmar Contraseña</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="fas fa-lock text-gray-400"></i>
                            </div>
                            <input type="password" id="add-confirm-password" name="confirm-password" required
                                class="block w-full pl-10 pr-10 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-300"
                                placeholder="••••••••">
                            <button type="button" id="toggle-add-confirm-password" class="absolute inset-y-0 right-0 pr-3 flex items-center">
                                <i class="fas fa-eye text-gray-400 hover:text-gray-600 cursor-pointer"></i>
                            </button>
                        </div>
                    </div>
                </div>
                
                <div class="px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                    <button type="submit" class="w-full flex justify-center items-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-300">
                    <i class="fas fa-user-plus mr-2"></i>Registrar Usuario
                    </button>
                    <button type="button" id="cancel-add-user"
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal para editar usuario -->
<div id="edit-user-modal" class="fixed inset-0 z-50 hidden overflow-y-auto">
    <!-- Fondo oscuro con transición -->
    <div id="edit-modal-backdrop" class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity duration-300 ease-in-out opacity-0"></div>
    
    <div class="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
        
        <!-- Contenido del modal con animación -->
        <div id="edit-modal-content" class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95">
            <div class="bg-gradient-to-r from-blue-600 to-purple-500 p-6 text-white">
                <h1 class="text-2xl font-bold flex items-center gap-2 justify-center">
                <i class="fas fa-user-plus"></i> Editar Usuario
                <button id="close-edit-user-modal" class="absolute top-4 right-4 text-white hover:text-gray-200 transition duration-200">
                    <i class="fas fa-times"></i>
                </button>
                <script>
                const closeEditBtn = document.getElementById('close-edit-user-modal');
                if (closeEditBtn) {
                    closeEditBtn.addEventListener('click', function () {
                        const modal = document.getElementById('edit-user-modal');
                        const backdrop = document.getElementById('edit-modal-backdrop');
                        const content = document.getElementById('edit-modal-content');

                        backdrop.classList.remove('opacity-100');
                        backdrop.classList.add('opacity-0');
                        content.classList.remove('opacity-100', 'translate-y-0', 'sm:scale-100');
                        content.classList.add('opacity-0', 'translate-y-4', 'sm:scale-95');

                        setTimeout(() => {
                            modal.classList.add('hidden');
                            document.getElementById('edit-user-form').reset();
                        }, 300);
                    });
                }
                </script>
            </div>
            
            <form id="edit-user-form" class="p-6 space-y-4">
                <input type="hidden" id="edit-cedula" name="cedula">
                
                <div class="grid grid-cols-1 gap-4">
                    <div>
                        <label for="edit-nombre" class="block text-sm font-medium text-gray-700 mb-1">Nombre</label>
                        <input type="text" id="edit-nombre" name="nombre" required
                            class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    </div>
                    
                    <div>
                        <label for="edit-apellido" class="block text-sm font-medium text-gray-700 mb-1">Apellido</label>
                        <input type="text" id="edit-apellido" name="apellido" required
                            class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    </div>
                    
                    <div>
                        <label for="edit-email" class="block text-sm font-medium text-gray-700 mb-1">Email</label>
                        <input type="email" id="edit-email" name="email" required
                            class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                    </div>
                    
                    <div>
                        <label for="edit-rol" class="block text-sm font-medium text-gray-700 mb-1">Rol</label>
                        <select id="edit-rol" name="id_rol" required
                            class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                            <option value="1">Administrador</option>
                            <option value="2">Usuario</option>
                        </select>
                    </div>
                </div>
                
                <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                    <button type="submit"
                    class="w-full flex justify-center items-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-300">
                    <i class="fas fa-save mr-2"></i> Guardar Cambios
                </button>
                    <button type="button" id="cancel-edit-user"
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal de éxito -->
<div id="success-modal" class="hidden fixed inset-0 overflow-y-auto z-50">
    <div class="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
        <div class="fixed inset-0 transition-opacity" aria-hidden="true">
            <div class="absolute inset-0 bg-gray-500 opacity-75"></div>
        </div>
        
        <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
        
        <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-md sm:w-full">
            <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <div class="sm:flex sm:items-start">
                    <div class="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-green-100 sm:mx-0 sm:h-10 sm:w-10">
                        <i class="fas fa-check text-green-600 animate-bounce"></i>
                    </div>
                    <div class="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                        <h3 class="text-lg leading-6 font-medium text-gray-900" id="success-title">Éxito</h3>
                        <div class="mt-2">
                            <p class="text-sm text-gray-500" id="success-message">Usuario registrado exitosamente</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    <!-- JavaScript -->
    <script src="../assets/js/admin.js"></script>
    <script>const closeBtn = document.getElementById('close-add-user-modal');
if (closeBtn) {
    closeBtn.addEventListener('click', function () {
        const modal = document.getElementById('add-user-modal');
        const backdrop = document.getElementById('modal-backdrop');
        const content = document.getElementById('modal-content');

        backdrop.classList.remove('opacity-100');
        backdrop.classList.add('opacity-0');
        content.classList.remove('opacity-100', 'translate-y-0', 'sm:scale-100');
        content.classList.add('opacity-0', 'translate-y-4', 'sm:scale-95');

        setTimeout(() => {
            modal.classList.add('hidden');
            document.getElementById('add-user-form').reset();
        }, 300);
    });
}
</script>
</body>
</html>