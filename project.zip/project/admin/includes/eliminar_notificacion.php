<?php
session_start();
require_once '../../includes/conexion.php';

header('Content-Type: application/json');

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$notificationId = isset($data['id']) ? (int)$data['id'] : null;

if (!$notificationId) {
    echo json_encode(['success' => false, 'message' => 'ID de notificación no proporcionado']);
    exit;
}

try {
    // Verificar que la notificación pertenece al usuario actual
    $stmt = $pdo->prepare("DELETE FROM notificaciones WHERE id = ? AND cedula_usuario = ?");
    $stmt->execute([$notificationId, $_SESSION['user_id']]);
    
    if ($stmt->rowCount() > 0) {
        echo json_encode(['success' => true, 'message' => 'Notificación eliminada']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Notificación no encontrada o no tienes permiso']);
    }
} catch (PDOException $e) {
    error_log("Error al eliminar notificación: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Error al eliminar notificación']);
}
?>