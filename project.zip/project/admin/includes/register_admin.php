<?php
require_once 'conexion.php';

header('Content-Type: application/json');

// 1. Verificar método POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
    exit;
}

// 2. Obtener y validar datos
$cedula = trim($_POST['cedula'] ?? '');
$nombre = trim($_POST['nombre'] ?? '');
$apellido = trim($_POST['apellido'] ?? '');
$email = filter_var(trim($_POST['email'] ?? ''), FILTER_VALIDATE_EMAIL);
$password = $_POST['password'] ?? '';
$id_rol = isset($_POST['id_rol']) ? (int)$_POST['id_rol'] : null;

// 3. Validaciones
$errors = [];

// Validar cédula
if (empty($cedula)) {
    $errors[] = 'La cédula es obligatoria';
} elseif (!preg_match('/^[0-9]{6,20}$/', $cedula)) {
    $errors[] = 'Cédula inválida (solo números, 6-20 dígitos)';
}

// Validar nombre y apellido
if (empty($nombre)) $errors[] = 'El nombre es obligatorio';
if (empty($apellido)) $errors[] = 'El apellido es obligatorio';

// Validar email
if (!$email) $errors[] = 'Email inválido';

// Validar contraseña
if (strlen($password) < 8) {
    $errors[] = 'La contraseña debe tener al menos 8 caracteres';
} elseif (!preg_match('/[A-Za-z]/', $password) || !preg_match('/[0-9]/', $password)) {
    $errors[] = 'La contraseña debe contener letras y números';
}

// Validar rol (según tu select)
if (!in_array($id_rol, [1, 2])) {
    $errors[] = 'Debe seleccionar un rol válido';
}

// Si hay errores, retornarlos
if (!empty($errors)) {
    echo json_encode(['success' => false, 'message' => implode('<br>', $errors)]);
    exit;
}

try {
    // 4. Verificar existencia del rol en la BD
    $stmt = $pdo->prepare("SELECT id_rol FROM roles WHERE id_rol = ?");
    $stmt->execute([$id_rol]);
    
    if ($stmt->rowCount() === 0) {
        throw new Exception('El rol seleccionado no existe en la base de datos');
    }

    // 5. Hashear contraseña
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    // 6. Llamar al procedimiento almacenado
    $stmt = $pdo->prepare("CALL sp_registrar_usuario(?, ?, ?, ?, ?, ?, @resultado, @error)");
    $stmt->execute([$cedula, $nombre, $apellido, $email, $hashed_password, $id_rol]);
    
    // 7. Obtener resultado
    $result = $pdo->query("SELECT @resultado AS resultado, @error AS error")->fetch(PDO::FETCH_ASSOC);
    
    if ($result['error']) {
        throw new Exception($result['resultado']);
    }

    // 8. Registrar en logs
    $rol_text = $id_rol == 1 ? 'Administrador' : 'Usuario';
    $stmt = $pdo->prepare("INSERT INTO logs_autenticacion (cedula_usuario, tipo_evento, direccion_ip, user_agent, detalles) 
                          VALUES (?, 'registro', ?, ?, ?)");
    $stmt->execute([
        $cedula,
        $_SERVER['REMOTE_ADDR'],
        $_SERVER['HTTP_USER_AGENT'] ?? 'AdminPanel',
        "Usuario registrado como $rol_text por administrador"
    ]);

    // 9. Respuesta exitosa
    echo json_encode([
        'success' => true,
        'message' => "Usuario registrado exitosamente como $rol_text",
        'data' => [
            'cedula' => $cedula,
            'nombre' => "$nombre $apellido",
            'email' => $email,
            'rol' => $rol_text
        ]
    ]);

} catch (PDOException $e) {
    error_log("PDO Error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Error de base de datos al registrar usuario',
        'error' => $e->getMessage()
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}
?>