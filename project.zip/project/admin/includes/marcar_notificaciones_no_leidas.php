<?php
session_start();
require_once '../../includes/conexion.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit;
}

try {
    // Contar solo notificaciones no leídas del usuario actual
    $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM notificaciones WHERE leida = 0 AND cedula_usuario = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    echo json_encode(['success' => true, 'count' => $result['count']]);
} catch (PDOException $e) {
    error_log("Error al contar notificaciones: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Error al contar notificaciones']);
}
?>