<?php
session_start();
require_once '../../includes/conexion.php';

header('Content-Type: application/json');

// Verificar si el usuario está autenticado y es administrador
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 1) {
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$cedula = $data['cedula'] ?? null;

if (!$cedula) {
    echo json_encode(['success' => false, 'message' => 'Cédula no proporcionada']);
    exit;
}

try {
    // Desbloquear usuario
    $stmt = $pdo->prepare("CALL sp_actualizar_estado_usuario(?, 'activo', @resultado, @error)");
    $stmt->execute([$cedula]);
    
    // Registrar notificación
    $stmt = $pdo->prepare("INSERT INTO notificaciones (titulo, mensaje, tipo, cedula_usuario) VALUES (?, ?, 'desbloqueo', ?)");
    $stmt->execute([
        'Usuario desbloqueado',
        'El usuario con cédula ' . $cedula . ' ha sido desbloqueado',
        $_SESSION['user_id']
    ]);
    
    echo json_encode(['success' => true, 'message' => 'Usuario desbloqueado correctamente']);
} catch (PDOException $e) {
    error_log("Error al desbloquear usuario: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Error al desbloquear usuario']);
}
?>