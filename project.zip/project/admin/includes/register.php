<?php
require_once '../../includes/conexion.php';

$mensaje = "";
$tipoMensaje = "";
$redirect = false;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $cedula = trim($_POST['cedula']);
    $nombre = trim($_POST['nombre']);
    $apellido = trim($_POST['apellido']);
    $email = trim($_POST['email']);
    $contrasenaPlano = $_POST['password'];
    $id_rol = 1; // 1 = admin (según tu base de datos)

    // Validaciones
    if (!preg_match('/^\d{1,10}$/', $cedula)) {
        $mensaje = "La cédula debe contener solo números y máximo 10 dígitos.";
        $tipoMensaje = "error";
    } elseif (strlen($contrasenaPlano) < 8) {
        $mensaje = "La contraseña debe tener al menos 8 caracteres.";
        $tipoMensaje = "error";
    } elseif (!preg_match('/^[\w.+-]+@(gmail|hotmail|outlook|icloud)\.com$/i', $email)) {
        $mensaje = "Solo se permiten correos de Gmail, Outlook, Hotmail o iCloud.";
        $tipoMensaje = "error";
    } else {
        $contrasena = password_hash($contrasenaPlano, PASSWORD_DEFAULT);
        $direccion_ip = $_SERVER['REMOTE_ADDR'] ?? 'desconocido';
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? 'desconocido';

        try {
            $pdo->beginTransaction();

            // Llamar al procedimiento almacenado con el rol fijo como admin (id_rol = 1)
            $stmt = $pdo->prepare("CALL sp_registrar_usuario(:cedula, :nombre, :apellido, :email, :contrasena, :id_rol, @p_resultado, @p_error)");
            $stmt->execute([
                ':cedula' => $cedula,
                ':nombre' => $nombre,
                ':apellido' => $apellido,
                ':email' => $email,
                ':contrasena' => $contrasena,
                ':id_rol' => $id_rol
            ]);

            // Obtener los resultados del procedimiento
            $result = $pdo->query("SELECT @p_resultado AS resultado, @p_error AS error")->fetch(PDO::FETCH_ASSOC);

            if (!empty($result['error'])) {
                $pdo->rollBack();
                $mensaje = $result['resultado'];
                $tipoMensaje = "error";
            } else {
                // Registrar log de autenticación usando el procedimiento almacenado
                $log = $pdo->prepare("CALL sp_registrar_log_autenticacion(:cedula, 'registro', :ip, :user_agent, :detalles)");
                $log->execute([
                    ':cedula' => $cedula,
                    ':ip' => $direccion_ip,
                    ':user_agent' => $user_agent,
                    ':detalles' => "Registro exitoso de administrador con correo $email"
                ]);

                $pdo->commit();
                $mensaje = "Administrador registrado exitosamente";
                $tipoMensaje = "exito";
                $redirect = true;
            }

        } catch (PDOException $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $mensaje = "Error en la base de datos: " . $e->getMessage();
            $tipoMensaje = "error";
        }
    }
}
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de administrador</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/auth.css">
</head>
<body class="min-h-screen flex items-center justify-center p-4">
    <div class="bg-white rounded-lg shadow-2xl overflow-hidden w-full max-w-md transform transition-all duration-500">
        <div class="bg-gradient-to-r from-blue-600 to-purple-500 p-6 text-white">
            <h1 class="text-2xl font-bold flex items-center gap-2 flex items-center justify-center">
                <i class="fas fa-user-plus"></i> Crear Cuenta
            </h1>
            <p class="text-green-100 text-center">Completa el formulario para registrarte</p>
        </div>
        
        <form class="p-6 space-y-6" id="registerForm" action="../includes/register.php" method="POST">
            <div class="space-y-4">
                <div>
                    <label for="cedula" class="block text-sm font-medium text-gray-700 mb-1">Cédula</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-id-card text-gray-400"></i>
                        </div>
                        <input type="text" id="cedula" name="cedula" required
                            class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-300"
                            placeholder="1234567890" pattern="[0-9]{6,20}" title="Ingrese su número de identificación sin guiones o espacios">
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label for="nombre" class="block text-sm font-medium text-gray-700 mb-1">Nombre</label>
                        <div class="relative">
                            <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                <i class="fas fa-user text-gray-400"></i>
                            </div>
                            <input type="text" id="nombre" name="nombre" required
                                class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-300"
                                placeholder="Nombre">
                        </div>
                    </div>
                    
                    <div>
                        <label for="apellido" class="block text-sm font-medium text-gray-700 mb-1">Apellido</label>
                        <input type="text" id="apellido" name="apellido" required
                            class="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-300"
                            placeholder="Apellido">
                    </div>
                </div>
                
                <div>
                    <label for="email" class="block text-sm font-medium text-gray-700 mb-1">Correo Electrónico</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-envelope text-gray-400"></i>
                        </div>
                        <input type="email" id="email" name="email" required
                            class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-300"
                            placeholder="tu@email.com">
                    </div>
                </div>
                
                <div>
                    <label for="password" class="block text-sm font-medium text-gray-700 mb-1">Contraseña</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-lock text-gray-400"></i>
                        </div>
                        <input type="password" id="password" name="password" required
                            class="block w-full pl-10 pr-10 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-300"
                            placeholder="••••••••" minlength="8" pattern="^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$" 
                            title="Mínimo 8 caracteres, al menos una letra y un número">
                        <button type="button" id="togglePassword" class="absolute inset-y-0 right-0 pr-3 flex items-center">
                            <i class="fas fa-eye text-gray-400 hover:text-gray-600 cursor-pointer"></i>
                        </button>
                    </div>
                    <p class="mt-1 text-xs text-gray-500">Mínimo 8 caracteres con números y letras</p>
                </div>
                
                <div>
                    <label for="confirm-password" class="block text-sm font-medium text-gray-700 mb-1">Confirmar Contraseña</label>
                    <div class="relative">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <i class="fas fa-lock text-gray-400"></i>
                        </div>
                        <input type="password" id="confirm-password" name="confirm-password" required
                            class="block w-full pl-10 pr-10 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition duration-300"
                            placeholder="••••••••">
                        <button type="button" id="toggleConfirmPassword" class="absolute inset-y-0 right-0 pr-3 flex items-center">
                            <i class="fas fa-eye text-gray-400 hover:text-gray-600 cursor-pointer"></i>
                        </button>
                    </div>
                </div>
                
                <div class="flex items-center">
                    <input id="terms" name="terms" type="checkbox" required
                        class="h-4 w-4 text-blue-600 focus:ring-green-500 border-gray-300 rounded">
                    <label for="terms" class="ml-2 block text-sm text-gray-700">
                        Acepto los <a href="#" class="text-blue-600 hover:text-blue-500 transition duration-300">Términos y Condiciones</a>
                    </label>
                </div>
            </div>
            
            <div>
                <button type="submit"
                    class="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition duration-300">
                    <i class="fas fa-user-plus mr-2"></i> Registrarme
                </button>
            </div>
        </form>
        
        <div class="px-6 py-4 bg-gray-50 text-center">
            <p class="text-sm text-gray-600">
                ¿Ya tienes una cuenta? 
                <a href="login.php" class="font-medium text-blue-600 hover:text-green-500 transition duration-300">Inicia Sesión</a>
            </p>
        </div>
    </div>

    <!-- Modal de Éxito -->
    <?php if ($tipoMensaje == "exito"): ?>
    <div id="modalExito" class="fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50">
        <div class="bg-white rounded-lg p-6 max-w-sm w-full mx-4 text-center">
            <div class="text-green-500 mb-4">
                <i class="fas fa-check-circle text-6xl animate-bounce"></i>
            </div>
            <h3 class="text-lg font-medium text-gray-900 mb-2">¡Registro exitoso!</h3>
            <p class="text-sm text-gray-500"><?php echo $mensaje; ?></p>
            <p class="text-xs text-gray-400 mt-4">Redirigiendo...</p>
        </div>
    </div>
    <script>
        setTimeout(function() {
            window.location.href = '../../auth/login.php';
        }, 3000);
    </script>
    <?php endif; ?>

    <!-- Modal de Error -->
    <?php if ($tipoMensaje == "error"): ?>
    <div id="modalError" class="fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50">
        <div class="bg-white rounded-lg p-6 max-w-sm w-full mx-4 text-center">
            <div class="text-red-500 mb-4">
                <i class="fas fa-exclamation-circle text-6xl animate-spin-slow"></i>
            </div>
            <h3 class="text-lg font-medium text-gray-900 mb-2">Error en el registro</h3>
            <p class="text-sm text-gray-500"><?php echo $mensaje; ?></p>
            <p class="text-xs text-gray-400 mt-4">Esta ventana se cerrará automáticamente</p>
        </div>
    </div>
    <script>
        setTimeout(function() {
            window.location.href = '../auth/register.php';
        }, 3000);
    </script>
    <?php endif; ?>
</body>
</html>