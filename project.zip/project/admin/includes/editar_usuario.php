<?php
require_once '../../includes/conexion.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    try {
        $pdo->beginTransaction();
        
        $stmt = $pdo->prepare("CALL sp_editar_usuario(:cedula, :nombre, :apellido, :email, :id_rol, @p_resultado, @p_error)");
        $stmt->execute([
            ':cedula' => $data['cedula'],
            ':nombre' => $data['nombre'],
            ':apellido' => $data['apellido'],
            ':email' => $data['email'],
            ':id_rol' => $data['id_rol']
        ]);
        
        $result = $pdo->query("SELECT @p_resultado AS resultado, @p_error AS error")->fetch(PDO::FETCH_ASSOC);
        
        if (!empty($result['error'])) {
            $pdo->rollBack();
            echo json_encode(['success' => false, 'message' => $result['resultado']]);
        } else {
            $pdo->commit();
            echo json_encode(['success' => true, 'message' => $result['resultado']]);
        }
    } catch (PDOException $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        echo json_encode(['success' => false, 'message' => 'Error al actualizar usuario: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Método no permitido']);
}
?>