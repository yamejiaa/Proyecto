<?php
session_start();
require_once '../../includes/conexion.php';

header('Content-Type: application/json');

// Verificar si el usuario está autenticado y es administrador
if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] != 1) {
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$cedula = $data['cedula'] ?? null;

if (!$cedula) {
    echo json_encode(['success' => false, 'message' => 'Cédula no proporcionada']);
    exit;
}

try {
    // Bloquear usuario
    $stmt = $pdo->prepare("CALL sp_actualizar_estado_usuario(?, 'bloqueado', @resultado, @error)");
    $stmt->execute([$cedula]);
    
    // Registrar notificación
    $stmt = $pdo->prepare("INSERT INTO notificaciones (titulo, mensaje, tipo, cedula_usuario) VALUES (?, ?, 'bloqueo', ?)");
    $stmt->execute([
        'Usuario bloqueado',
        'El usuario con cédula ' . $cedula . ' ha sido bloqueado',
        $_SESSION['user_id']
    ]);
    
    echo json_encode(['success' => true, 'message' => 'Usuario bloqueado correctamente']);
} catch (PDOException $e) {
    error_log("Error al bloquear usuario: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Error al bloquear usuario']);
}
?>