<?php
session_start();
require_once '../../includes/conexion.php';

header('Content-Type: application/json');

// Verificar si el usuario está autenticado
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit;
}

try {
    $stmt = $pdo->prepare("DELETE FROM notificaciones WHERE cedula_usuario = ?");
    $stmt->execute([$_SESSION['user_id']]);
    
    echo json_encode(['success' => true, 'message' => 'Notificaciones eliminadas']);
} catch (PDOException $e) {
    error_log("Error al eliminar notificaciones: " . $e->getMessage());
    echo json_encode(['success' => false, 'message' => 'Error al eliminar notificaciones']);
}
?>