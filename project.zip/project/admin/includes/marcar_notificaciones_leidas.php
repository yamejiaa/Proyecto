<?php
require_once '../../includes/conexion.php';

session_start();

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id'])) {
    try {
        $pdo->beginTransaction();
        
        // Marcar solo las no leídas como leídas
$stmt = $pdo->prepare("UPDATE notificaciones SET leida = 1 WHERE cedula_usuario = ? AND leida = 0");
$stmt->execute([$_SESSION['user_id']]);

// Obtener el nuevo conteo
$countStmt = $pdo->prepare("SELECT COUNT(*) as count FROM notificaciones WHERE cedula_usuario = ? AND leida = 0");
$countStmt->execute([$_SESSION['user_id']]);
$count = $countStmt->fetch(PDO::FETCH_ASSOC)['count'];
        
        $pdo->commit();
        
        echo json_encode([
            'success' => true,
            'count' => $count  // Devolver el nuevo conteo
        ]);
    } catch (PDOException $e) {
        $pdo->rollBack();
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Solicitud no válida']);
}
?>