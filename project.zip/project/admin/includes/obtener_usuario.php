<?php
require_once '../../includes/conexion.php';

header('Content-Type: application/json');

if (!isset($_GET['cedula'])) {
    echo json_encode(['success' => false, 'message' => 'Cédula no proporcionada']);
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT cedula, nombre, apellido, email, id_rol FROM usuarios WHERE cedula = ?");
    $stmt->execute([$_GET['cedula']]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($usuario) {
        echo json_encode(['success' => true, 'usuario' => $usuario]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Usuario no encontrado']);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Error al obtener usuario: ' . $e->getMessage()]);
}
?>